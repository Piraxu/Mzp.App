  document.oncontextmenu = function() {
    return false;
};


function titlechange() {
        var apptitle = document.getElementById("chtitle")
        if(apptitle.innerText === "MZP APP - Wybierz Rozkład") {
apptitle.innerHTML = "Szczęśliwego nowego 2026 roku !"
        } else {
            apptitle.innerText = "MZP APP - Wybierz Rozkład"
        }

        setTimeout(titlechange,5000)
}

function setwindow() {
            var szerokosc = 1006;
            var wysokosc = 518;
            window.resizeTo(szerokosc, wysokosc);
            window.moveTo(
                (screen.availWidth - szerokosc) / 2,
                (screen.availHeight - wysokosc) / 2
            );
}

function enforceWindowSize() {
            var szerokosc = 1006;
            var wysokosc = 518;

            if (window.outerWidth !== szerokosc || window.outerHeight !== wysokosc) {
                window.resizeTo(szerokosc, wysokosc);
                window.moveTo(
                    (screen.availWidth - szerokosc) / 2,
                    (screen.availHeight - wysokosc) / 2
                );
            }
}


function loadsettings() {
    var theme = readFile("properties//theme.prop")
    var cssheet = document.getElementById("css")

if(theme === "dark") {
cssheet.href = "resources/css/D_Main.css"
} else {
    cssheet.href = "resources/css/L_Main.css"
}

var popup = readFile("properties/popup.prop")

if(popup === "true") {
    loadMsg();
} else {
    return;
}

}

function clock() {
  var today = new Date();
  var h = today.getHours();
  var m = today.getMinutes();
  var s = today.getSeconds();
  if(h<10) h = "0"+h
  if(m<10) m = "0"+m
  if(s<10) s = "0"+s

  document.getElementById("hour").innerHTML = h;
  document.getElementById("minute").innerHTML = m;
  document.getElementById("secound").innerHTML = s;

  setTimeout(clock,1000);
}

function nameday() {
    var now = new Date();
    var day = now.getDate();
    var month = now.getMonth()+1;
    var weekday = now.getDay();
    var year = now.getFullYear();
    if(day<10) day = "0"+day
    if(month<10) month = "0"+month
    var DOM = day+"."+month;
    var nameday = ""
    

if (DOM === "01.01") {
        nameday = "Mieszka, Mieczysława";
    } else if (DOM === "02.01") {
        nameday = "Izydora, Grzegorza";
    } else if (DOM === "03.01") {
        nameday = "Danuty, Genowefy";
    } else if (DOM === "04.01") {
        nameday = "Elżbiety, Anieli";
    } else if (DOM === "05.01") {
        nameday = "Hanny, Edwarda";
    } else if (DOM === "06.01") {
        nameday = "Kacpra, Melchiora";
    } else if (DOM === "07.01") {
        nameday = "Lucjana, Juliana";
    } else if (DOM === "08.01") {
        nameday = "Seweryna, Teofila";
    } else if (DOM === "09.01") {
        nameday = "Adriana, Alicji";
    } else if (DOM === "10.01") {
        nameday = "Jana, Wilhelma";
    } else if (DOM === "11.01") {
        nameday = "Honoraty, Matyldy";
    } else if (DOM === "12.01") {
        nameday = "Benedykta, Arkadiusza";
    } else if (DOM === "13.01") {
        nameday = "Bogumiły, Weroniki";
    } else if (DOM === "14.01") {
        nameday = "Feliksa, Niny";
    } else if (DOM === "15.01") {
        nameday = "Pawła, Arnolda";
    } else if (DOM === "16.01") {
        nameday = "Marcelego, Włodzimierza";
    } else if (DOM === "17.01") {
        nameday = "Antoniego, Jana";
    } else if (DOM === "18.01") {
        nameday = "Małgorzaty, Piotra";
    } else if (DOM === "19.01") {
        nameday = "Henryka, Marty";
    } else if (DOM === "20.01") {
        nameday = "Fabiana, Sebastiana";
    } else if (DOM === "21.01") {
        nameday = "Agnieszki, Jarosława";
    } else if (DOM === "22.01") {
        nameday = "Anastazego, Wincentego";
    } else if (DOM === "23.01") {
        nameday = "Iidelfonsa, Rajmunda";
    } else if (DOM === "24.01") {
        nameday = "Rafała, Felicji";
    } else if (DOM === "25.01") {
        nameday = "Pawła, Miłosza";
    } else if (DOM === "26.01") {
        nameday = "Pauliny, Tymoteusza";
    } else if (DOM === "27.01") {
        nameday = "Przybysława, Jana";
    } else if (DOM === "28.01") {
        nameday = "Radomira, Walerego";
    } else if (DOM === "29.01") {
        nameday = "Bolesławy, Franciszka";
    } else if (DOM === "30.01") {
        nameday = "Macieja, Martyny";
    } else if (DOM === "31.01") {
        nameday = "Marceli, Jana";
    } else if (DOM === "01.02") {
        nameday = "Brygidy, Ignacego";
    } else if (DOM === "02.02") {
        nameday = "Marii, Mirosława";
    } else if (DOM === "03.02") {
        nameday = "Błażeja, Oskara";
    } else if (DOM === "04.02") {
        nameday = "Weroniki, Żanety";
    } else if (DOM === "05.02") {
        nameday = "Agaty, Adelajdy";
    } else if (DOM === "06.02") {
        nameday = "Doroty, Tytusa";
    } else if (DOM === "07.02") {
        nameday = "Ryszarda, Teodora";
    } else if (DOM === "08.02") {
        nameday = "Jana, Piotra";
    } else if (DOM === "09.02") {
        nameday = "Apolonii, Eryki";
    } else if (DOM === "10.02") {
        nameday = "Jacka, Scholastyki";
    } else if (DOM === "11.02") {
        nameday = "Łazarza, Marii";
    } else if (DOM === "12.02") {
        nameday = "Eulalii, Modesta";
    } else if (DOM === "13.02") {
        nameday = "Grzegorza, Katarzyny";
    } else if (DOM === "14.02") {
        nameday = "Metodego, Walentego";
    } else if (DOM === "15.02") {
        nameday = "Jowity, Faustyny";
    } else if (DOM === "16.02") {
        nameday = "Danuty, Juliany";
    } else if (DOM === "17.02") {
        nameday = "Aleksandra, Łukasza";
    } else if (DOM === "18.02") {
        nameday = "Szymona, Konstancji";
    } else if (DOM === "19.02") {
        nameday = "Arnolda, Józefa";
    } else if (DOM === "20.02") {
        nameday = "Leona, Ludomira";
    } else if (DOM === "21.02") {
        nameday = "Roberta, Eleonory";
    } else if (DOM === "22.02") {
        nameday = "Marty, Małgorzaty";
    } else if (DOM === "23.02") {
        nameday = "Romany, Damiana";
    } else if (DOM === "24.02") {
        nameday = "Macieja, Marka";
    } else if (DOM === "25.02") {
        nameday = "Cezarego, Donata";
    } else if (DOM === "26.02") {
        nameday = "Mirosława, Aleksandra";
    } else if (DOM === "27.02") {
        nameday = "Gabriela, Anastazji";
    } else if (DOM === "28.02") {
        nameday = "Romana, Makarego";
    } else if (DOM === "29.02") {
        nameday = "Antonia, Augusta"
    }
     else if (DOM === "01.03") {
        nameday = "Radosława, Antoniego";
    } else if (DOM === "02.03") {
        nameday = "Heleny, Pawła";
    } else if (DOM === "03.03") {
        nameday = "Tycjana, Kunegundy";
    } else if (DOM === "04.03") {
        nameday = "Kazimierza, Łucji";
    } else if (DOM === "05.03") {
        nameday = "Oliwii, Adriana";
    } else if (DOM === "06.03") {
        nameday = "Róży, Wiktora";
    } else if (DOM === "07.03") {
        nameday = "Pawła, Tomasza";
    } else if (DOM === "08.03") {
        nameday = "Beaty, Wincentego";
    } else if (DOM === "09.03") {
        nameday = "Franciszki, Katarzyny";
    } else if (DOM === "10.03") {
        nameday = "Cypriana, Aleksandra";
    } else if (DOM === "11.03") {
        nameday = "Benedykta, Konstantego";
    } else if (DOM === "12.03") {
        nameday = "Bernarda, Grzegorza";
    } else if (DOM === "13.03") {
        nameday = "Bożeny, Krystyny";
    } else if (DOM === "14.03") {
        nameday = "Leona, Matyldy";
    } else if (DOM === "15.03") {
        nameday = "Longina, Klemensa";
    } else if (DOM === "16.03") {
        nameday = "Izabeli, Hilarego";
    } else if (DOM === "17.03") {
        nameday = "Patryka, Zbigniewa";
    } else if (DOM === "18.03") {
        nameday = "Cyryla, Edwarda";
    } else if (DOM === "19.03") {
        nameday = "Józefa, Bogdana";
    } else if (DOM === "20.03") {
        nameday = "Klaudii, Eufemii";
    } else if (DOM === "21.03") {
        nameday = "Ludomira, Benedykta";
    } else if (DOM === "22.03") {
        nameday = "Katarzyny, Bogusława";
    } else if (DOM === "23.03") {
        nameday = "Pelagii, Feliksa";
    } else if (DOM === "24.03") {
        nameday = "Marka, Gabriela";
    } else if (DOM === "25.03") {
        nameday = "Marioli, Wieńczysława";
    } else if (DOM === "26.03") {
        nameday = "Emanuela, Larysy";
    } else if (DOM === "27.03") {
        nameday = "Lidii, Ernesta";
    } else if (DOM === "28.03") {
        nameday = "Anieli, Jana";
    } else if (DOM === "29.03") {
        nameday = "Wiktoryny, Eustachego";
    } else if (DOM === "30.03") {
        nameday = "Amelii, Leonarda";
    } else if (DOM === "31.03") {
        nameday = "Beniamina, Balbiny";
    } else if (DOM === "01.04") {
        nameday = "Grażyny, Ireny";
    } else if (DOM === "02.04") {
        nameday = "Władysława, Franciszka";
    } else if (DOM === "03.04") {
        nameday = "Ryszarda, Pankracego";
    } else if (DOM === "04.04") {
        nameday = "Benedykta, Izydora";
    } else if (DOM === "05.04") {
        nameday = "Katarzyny, Wincentego";
    } else if (DOM === "06.04") {
        nameday = "Izoldy, Ireneusza";
    } else if (DOM === "07.04") {
        nameday = "Hermana, Donata";
    } else if (DOM === "08.04") {
        nameday = "Dionizego, Julii";
    } else if (DOM === "09.04") {
        nameday = "Marii, Dymitra";
    } else if (DOM === "10.04") {
        nameday = "Michała, Makarego";
    } else if (DOM === "11.04") {
        nameday = "Filipa, Leona";
    } else if (DOM === "12.04") {
        nameday = "Dominika, Juliusza";
    } else if (DOM === "13.04") {
        nameday = "Przemysława, Idy";
    } else if (DOM === "14.04") {
        nameday = "Bereniki, Waleriana";
    } else if (DOM === "15.04") {
        nameday = "Anastazji, Bazylego";
    } else if (DOM === "16.04") {
        nameday = "Cecyliana, Bernadety";
    } else if (DOM === "17.04") {
        nameday = "Roberta, Rudolfa";
    } else if (DOM === "18.04") {
        nameday = "Alicji, Bogusławy";
    } else if (DOM === "19.04") {
        nameday = "Adolfa, Tymona";
    } else if (DOM === "20.04") {
        nameday = "Czesława, Agnieszki";
    } else if (DOM === "21.04") {
        nameday = "Bartosza, Feliksa";
    } else if (DOM === "22.04") {
        nameday = "Kai, Łukasza";
    } else if (DOM === "23.04") {
        nameday = "Jerzego, Idziego";
    } else if (DOM === "24.04") {
        nameday = "Aleksego, Horacego";
    } else if (DOM === "25.04") {
        nameday = "Marka, Jarosława";
    } else if (DOM === "26.04") {
        nameday = "Marzeny, Marii";
    } else if (DOM === "27.04") {
        nameday = "Zyty, Teofila";
    } else if (DOM === "28.04") {
        nameday = "Pawła, Walerii";
    } else if (DOM === "29.04") {
        nameday = "Rity, Piotra";
    } else if (DOM === "30.04") {
        nameday = "Mariana, Katarzyny";
    } else if (DOM === "01.05") {
        nameday = "Józefa, Jeremiasza";
    } else if (DOM === "02.05") {
        nameday = "Zygmunta, Anatola";
    } else if (DOM === "03.05") {
        nameday = "Marii, Marioli";
    } else if (DOM === "04.05") {
        nameday = "Moniki, Floriana";
    } else if (DOM === "05.05") {
        nameday = "Ireny, Waldemara";
    } else if (DOM === "06.05") {
        nameday = "Jana, Judyty";
    } else if (DOM === "07.05") {
        nameday = "Gizeli, Ludmiły";
    } else if (DOM === "08.05") {
        nameday = "Lizy, Wiktora";
    } else if (DOM === "09.05") {
        nameday = "Bożydara, Grzegorza";
    } else if (DOM === "10.05") {
        nameday = "Izydora, Antoniny";
    } else if (DOM === "11.05") {
        nameday = "Igi, Ignacego";
    } else if (DOM === "12.05") {
        nameday = "Joanny, Pankracego";
    } else if (DOM === "13.05") {
        nameday = "Roberta, Serwacego";
    } else if (DOM === "14.05") {
        nameday = "Bonifacego, Dobiesława";
    } else if (DOM === "15.05") {
        nameday = "Zofii, Strzeżysława";
    } else if (DOM === "16.05") {
        nameday = "Andrzeja, Wieńczysława";
    } else if (DOM === "17.05") {
        nameday = "Brunona, Paschalisa";
    } else if (DOM === "18.05") {
        nameday = "Feliksa, Aleksandry";
    } else if (DOM === "19.05") {
        nameday = "Piotra, Mikołaja";
    } else if (DOM === "20.05") {
        nameday = "Aleksandra, Bazylego";
    } else if (DOM === "21.05") {
        nameday = "Jana, Wiktora";
    } else if (DOM === "22.05") {
        nameday = "Heleny, Wiesława";
    } else if (DOM === "23.05") {
        nameday = "Emilii, Iwony";
    } else if (DOM === "24.05") {
        nameday = "Joanny, Zuzanny";
    } else if (DOM === "25.05") {
        nameday = "Urbana, Grzegorza";
    } else if (DOM === "26.05") {
        nameday = "Filipa, Pauliny";
    } else if (DOM === "27.05") {
        nameday = "Augustyna, Juliana";
    } else if (DOM === "28.05") {
        nameday = "Jaromira, Justa";
    } else if (DOM === "29.05") {
        nameday = "Teodozji, Magdaleny";
    } else if (DOM === "30.05") {
        nameday = "Feliksa, Ferdynanda";
    } else if (DOM === "31.05") {
        nameday = "Anieli, Petroneli";
    } else if (DOM === "01.06") {
        nameday = "Jakuba, Konrada";
    } else if (DOM === "02.06") {
        nameday = "Erazma, Marianny";
    } else if (DOM === "03.06") {
        nameday = "Leszka, Tamary";
    } else if (DOM === "04.06") {
        nameday = "Franciszka, Karola";
    } else if (DOM === "05.06") {
        nameday = "Bonifacego, Waltera";
    } else if (DOM === "06.06") {
        nameday = "Norberta, Laurentego";
    } else if (DOM === "07.06") {
        nameday = "Roberta, Wiesława";
    } else if (DOM === "08.06") {
        nameday = "Maksyma, Medarda";
    } else if (DOM === "09.06") {
        nameday = "Anny, Felicjana";
    } else if (DOM === "10.06") {
        nameday = "Bogumiła, Małgorzaty";
    } else if (DOM === "11.06") {
        nameday = "Barnaby, Radomiła";
    } else if (DOM === "12.06") {
        nameday = "Janiny, Jana";
    } else if (DOM === "13.06") {
        nameday = "Lucjana, Antoniego";
    } else if (DOM === "14.06") {
        nameday = "Bazylego, Elizy";
    } else if (DOM === "15.06") {
        nameday = "Wita, Jolanty";
    } else if (DOM === "16.06") {
        nameday = "Aliny, Benona";
    } else if (DOM === "17.06") {
        nameday = "Laury, Adolfa";
    } else if (DOM === "18.06") {
        nameday = "Marka, Elżbiety";
    } else if (DOM === "19.06") {
        nameday = "Gerwazego, Protazego";
    } else if (DOM === "20.06") {
        nameday = "Diny, Bogny";
    } else if (DOM === "21.06") {
        nameday = "Alicji, Alojzego";
    } else if (DOM === "22.06") {
        nameday = "Pauliny, Tomasza";
    } else if (DOM === "23.06") {
        nameday = "Wandy, Zenona";
    } else if (DOM === "24.06") {
        nameday = "Jana, Danuty";
    } else if (DOM === "25.06") {
        nameday = "Łucji, Wilhelma";
    } else if (DOM === "26.06") {
        nameday = "Jana, Pawła";
    } else if (DOM === "27.06") {
        nameday = "Maryli, Władysława";
    } else if (DOM === "28.06") {
        nameday = "Leona, Ireneusza";
    } else if (DOM === "29.06") {
        nameday = "Piotra, Pawła";
    } else if (DOM === "30.06") {
        nameday = "Emilii, Lucyny";
    } else if (DOM === "01.07") {
        nameday = "Haliny, Mariana";
    } else if (DOM === "02.07") {
        nameday = "Jagody, Urbana";
    } else if (DOM === "03.07") {
        nameday = "Jacka, Anatola";
    } else if (DOM === "04.07") {
        nameday = "Malwiny, Teodora";
    } else if (DOM === "05.07") {
        nameday = "Karoliny, Antoniego";
    } else if (DOM === "06.07") {
        nameday = "Dominiki, Gotarda";
    } else if (DOM === "07.07") {
        nameday = "Benedykta, Cyryla";
    } else if (DOM === "08.07") {
        nameday = "Adriany, Eugeniusza";
    } else if (DOM === "09.07") {
        nameday = "Weroniki, Zenona";
    } else if (DOM === "10.07") {
        nameday = "Amelii, Witalisa";
    } else if (DOM === "11.07") {
        nameday = "Olgi, Kaliny";
    } else if (DOM === "12.07") {
        nameday = "Jana, Brunona";
    } else if (DOM === "13.07") {
        nameday = "Ernesta, Małgorzaty";
    } else if (DOM === "14.07") {
        nameday = "Bonawentury, Stelii";
    } else if (DOM === "15.07") {
        nameday = "Włodzimierza, Henryka";
    } else if (DOM === "16.07") {
        nameday = "Benedykta, Marii";
    } else if (DOM === "17.07") {
        nameday = "Anety, Bogdana";
    } else if (DOM === "18.07") {
        nameday = "Kamila, Szymona";
    } else if (DOM === "19.07") {
        nameday = "Wincentego, Wodzisława";
    } else if (DOM === "20.07") {
        nameday = "Czesława, Hieronima";
    } else if (DOM === "21.07") {
        nameday = "Daniela, Dalidy";
    } else if (DOM === "22.07") {
        nameday = "Marii, Magdaleny";
    } else if (DOM === "23.07") {
        nameday = "Bogny, Apolinarego";
    } else if (DOM === "24.07") {
        nameday = "Kingi, Krystyny";
    } else if (DOM === "25.07") {
        nameday = "Jakuba, Krzysztofa";
    } else if (DOM === "26.07") {
        nameday = "Anny, Mirosławy";
    } else if (DOM === "27.07") {
        nameday = "Natalii, Julii";
    } else if (DOM === "28.07") {
        nameday = "Wiktora, Innocentego";
    } else if (DOM === "29.07") {
        nameday = "Olafa, Marty";
    } else if (DOM === "30.07") {
        nameday = "Julity, Piotra";
    } else if (DOM === "31.07") {
        nameday = "Ignacego, Lubomira";
    } else if (DOM === "01.08") {
        nameday = "Alfonsa, Nadii";
    } else if (DOM === "02.08") {
        nameday = "Kariny, Gustawa";
    } else if (DOM === "03.08") {
        nameday = "Lidii, Augusta";
    } else if (DOM === "04.08") {
        nameday = "Dominika, Jana";
    } else if (DOM === "05.08") {
        nameday = "Marii, Oswalda";
    } else if (DOM === "06.08") {
        nameday = "Sławy, Jakuba";
    } else if (DOM === "07.08") {
        nameday = "Klaudii, Kajetana";
    } else if (DOM === "08.08") {
        nameday = "Cyryla, Seweryna";
    } else if (DOM === "09.08") {
        nameday = "Romana, Ryszarda";
    } else if (DOM === "10.08") {
        nameday = "Bogdana, Borysa";
    } else if (DOM === "11.08") {
        nameday = "Zuzanny, Klary";
    } else if (DOM === "12.08") {
        nameday = "Lecha, Euzebii";
    } else if (DOM === "13.08") {
        nameday = "Diany, Hipolita";
    } else if (DOM === "14.08") {
        nameday = "Alfreda, Euzebiusza";
    } else if (DOM === "15.08") {
        nameday = "Marii, Napoleona";
    } else if (DOM === "16.08") {
        nameday = "Stefana, Rocha";
    } else if (DOM === "17.08") {
        nameday = "Anity, Elizy";
    } else if (DOM === "18.08") {
        nameday = "Ilony, Klary";
    } else if (DOM === "19.08") {
        nameday = "Jana, Bolesława";
    } else if (DOM === "20.08") {
        nameday = "Bernarda, Samuela";
    } else if (DOM === "21.08") {
        nameday = "Franciszka, Joanny";
    } else if (DOM === "22.08") {
        nameday = "Marii, Cezarego";
    } else if (DOM === "23.08") {
        nameday = "Filipa, Apolinarego";
    } else if (DOM === "24.08") {
        nameday = "Jerzego, Bartłomieja";
    } else if (DOM === "25.08") {
        nameday = "Luizy, Ludwika";
    } else if (DOM === "26.08") {
        nameday = "Ireneusza, Zefiryny";
    } else if (DOM === "27.08") {
        nameday = "Moniki, Cezarego";
    } else if (DOM === "28.08") {
        nameday = "Patrycji, Wyszomira";
    } else if (DOM === "29.08") {
        nameday = "Sabiny, Jana";
    } else if (DOM === "30.08") {
        nameday = "Róży, Szczęsnego";
    } else if (DOM === "31.08") {
        nameday = "Izabeli, Ramony";
    } else if (DOM === "01.09") {
        nameday = "Bronisława, Idziego";
    } else if (DOM === "02.09") {
        nameday = "Juliana, Stefana";
    } else if (DOM === "03.09") {
        nameday = "Izabeli, Szymona";
    } else if (DOM === "04.09") {
        nameday = "Idy, Lilianny";
    } else if (DOM === "05.09") {
        nameday = "Doroty, Wawrzyńca";
    } else if (DOM === "06.09") {
        nameday = "Beaty, Eugeniusza";
    } else if (DOM === "07.09") {
        nameday = "Reginy, Melchiora";
    } else if (DOM === "08.09") {
        nameday = "Marii, Adrianny";
    } else if (DOM === "09.09") {
        nameday = "Piotra, Sergiusza";
    } else if (DOM === "10.09") {
        nameday = "Łukasza, Mikołaja";
    } else if (DOM === "11.09") {
        nameday = "Jacka, Dagny";
    } else if (DOM === "12.09") {
        nameday = "Radzimira, Gwidona";
    } else if (DOM === "13.09") {
        nameday = "Eugeni, Aureliusza";
    } else if (DOM === "14.09") {
        nameday = "Roksany, Bernarda";
    } else if (DOM === "15.09") {
        nameday = "Albina, Nikodema";
    } else if (DOM === "16.09") {
        nameday = "Edyty, Kornela";
    } else if (DOM === "17.09") {
        nameday = "Franciszka, Hildegardy";
    } else if (DOM === "18.09") {
        nameday = "Irmy, Józefa";
    } else if (DOM === "19.09") {
        nameday = "Januarego, Konstancji";
    } else if (DOM === "20.09") {
        nameday = "Filipiny, Eustachego";
    } else if (DOM === "21.09") {
        nameday = "Jonasza, Mateusza";
    } else if (DOM === "22.09") {
        nameday = "Tomasza, Maurycego";
    } else if (DOM === "23.09") {
        nameday = "Bogusława, Tekli";
    } else if (DOM === "24.09") {
        nameday = "Gerarda, Teodora";
    } else if (DOM === "25.09") {
        nameday = "Aurelii, Władysława";
    } else if (DOM === "26.09") {
        nameday = "Justyny, Cypriana";
    } else if (DOM === "27.09") {
        nameday = "Damiana, Amadeusza";
    } else if (DOM === "28.09") {
        nameday = "Luby, Wacława";
    } else if (DOM === "29.09") {
        nameday = "Michała, Michaliny";
    } else if (DOM === "30.09") {
        nameday = "Wery, Honoriusza";
    } else if (DOM === "01.10") {
        nameday = "Danuty, Remigiusza";
    } else if (DOM === "02.10") {
        nameday = "Teofila, Sławy";
    } else if (DOM === "03.10") {
        nameday = "Teresy, Heliodora";
    } else if (DOM === "04.10") {
        nameday = "Rozalii, Franciszka";
    } else if (DOM === "05.10") {
        nameday = "Igora, Flawii";
    } else if (DOM === "06.10") {
        nameday = "Artura, Brunona";
    } else if (DOM === "07.10") {
        nameday = "Marii, Marka";
    } else if (DOM === "08.10") {
        nameday = "Brygidy, Pelagii";
    } else if (DOM === "09.10") {
        nameday = "Arnolda, Dionizego";
    } else if (DOM === "10.10") {
        nameday = "Pauliny, Franciszka";
    } else if (DOM === "11.10") {
        nameday = "Emila, Aldony";
    } else if (DOM === "12.10") {
        nameday = "Eustachego, Maksymiliana";
    } else if (DOM === "13.10") {
        nameday = "Gerarda, Edwarda";
    } else if (DOM === "14.10") {
        nameday = "Alana, Kaliksta";
    } else if (DOM === "15.10") {
        nameday = "Teresy, Jadwigi";
    } else if (DOM === "16.10") {
        nameday = "Gawła, Florentyny";
    } else if (DOM === "17.10") {
        nameday = "Małgorzaty, Wiktora";
    } else if (DOM === "18.10") {
        nameday = "Juliana, Łukasza";
    } else if (DOM === "19.10") {
        nameday = "Pelagii, Piotra";
    } else if (DOM === "20.10") {
        nameday = "Ireny, Jana";
    } else if (DOM === "21.10") {
        nameday = "Urszuli, Hilarego";
    } else if (DOM === "22.10") {
        nameday = "Filipa, Korduli";
    } else if (DOM === "23.10") {
        nameday = "Marleny, Seweryna";
    } else if (DOM === "24.10") {
        nameday = "Rafała, Marcina";
    } else if (DOM === "25.10") {
        nameday = "Darii, Wilhelminy";
    } else if (DOM === "26.10") {
        nameday = "Lucjana, Ewarysta";
    } else if (DOM === "27.10") {
        nameday = "Iwony, Sabiny";
    } else if (DOM === "28.10") {
        nameday = "Szymona, Tadeusza";
    } else if (DOM === "29.10") {
        nameday = "Euzebii, Wioletty";
    } else if (DOM === "30.10") {
        nameday = "Zenobii, Przemysława";
    } else if (DOM === "31.10") {
        nameday = "Urbana, Saturnina";
    } else if (DOM === "01.11") {
        nameday = "Seweryna, Wiktoryny";
    } else if (DOM === "02.11") {
        nameday = "Bohdana, Tobiasza";
    } else if (DOM === "03.11") {
        nameday = "Sylwii, Huberta";
    } else if (DOM === "04.11") {
        nameday = "Karola, Olgierda";
    } else if (DOM === "05.11") {
        nameday = "Elżbiety, Sławomira";
    } else if (DOM === "06.11") {
        nameday = "Feliksa, Leonarda";
    } else if (DOM === "07.11") {
        nameday = "Antoniego, Żytomira";
    } else if (DOM === "08.11") {
        nameday = "Seweryna, Gotfryda";
    } else if (DOM === "09.11") {
        nameday = "Ursyna, Teodora";
    } else if (DOM === "10.11") {
        nameday = "Leny, Ludomira";
    } else if (DOM === "11.11") {
        nameday = "Marcina, Bartłomieja";
    } else if (DOM === "12.11") {
        nameday = "Renaty, Witolda";
    } else if (DOM === "13.11") {
        nameday = "Mikołaja, Stanisława";
    } else if (DOM === "14.11") {
        nameday = "Rogera, Serafina";
    } else if (DOM === "15.11") {
        nameday = "Alberta, Leopolda";
    } else if (DOM === "16.11") {
        nameday = "Gertrudy, Edmunda";
    } else if (DOM === "17.11") {
        nameday = "Grzegorza, Salomei";
    } else if (DOM === "18.11") {
        nameday = "Romana, Klaudyny";
    } else if (DOM === "19.11") {
        nameday = "Elżbiety, Seweryna";
    } else if (DOM === "20.11") {
        nameday = "Feliksa, Anatola";
    } else if (DOM === "21.11") {
        nameday = "Janusza, Konrada";
    } else if (DOM === "22.11") {
        nameday = "Marka, Cecylii";
    } else if (DOM === "23.11") {
        nameday = "Adeli, Klemensa";
    } else if (DOM === "24.11") {
        nameday = "Flory, Emmy";
    } else if (DOM === "25.11") {
        nameday = "Katarzyny, Erazma";
    } else if (DOM === "26.11") {
        nameday = "Delfiny, Sylwestra";
    } else if (DOM === "27.11") {
        nameday = "Waleriana, Wirgiliusza";
    } else if (DOM === "28.11") {
        nameday = "Lesława, Zdzisława";
    } else if (DOM === "29.11") {
        nameday = "Błażeja, Saturnina";
    } else if (DOM === "30.11") {
        nameday = "Konstantego, Maury";
    } else if (DOM === "01.12") {
        nameday = "Natalii, Eligiusza";
    } else if (DOM === "02.12") {
        nameday = "Balbiny, Pauliny";
    } else if (DOM === "03.12") {
        nameday = "Franciszka, Ksawerego";
    } else if (DOM === "04.12") {
        nameday = "Barbary, Krystiana";
    } else if (DOM === "05.12") {
        nameday = "Saby, Kryspina";
    } else if (DOM === "06.12") {
        nameday = "Emiliana, Mikołaja";
    } else if (DOM === "07.12") {
        nameday = "Marcina, Ambrożego";
    } else if (DOM === "08.12") {
        nameday = "Marii, Światożara";
    } else if (DOM === "09.12") {
        nameday = "Wiesława, Leokadii";
    } else if (DOM === "10.12") {
        nameday = "Julii, Danieli";
    } else if (DOM === "11.12") {
        nameday = "Damazego, Waldemara";
    } else if (DOM === "12.12") {
        nameday = "Adelajdy, Aleksandra";
    } else if (DOM === "13.12") {
        nameday = "Łucji, Otylii";
    } else if (DOM === "14.12") {
        nameday = "Alfreda, Izydora";
    } else if (DOM === "15.12") {
        nameday = "Celiny, Waleriana";
    } else if (DOM === "16.12") {
        nameday = "Albiny, Zdzisławy";
    } else if (DOM === "17.12") {
        nameday = "Olimpii, Łazarza";
    } else if (DOM === "18.12") {
        nameday = "Gracjana, Bogusława";
    } else if (DOM === "19.12") {
        nameday = "Gabrieli, Dariusza";
    } else if (DOM === "20.12") {
        nameday = "Bogumiły, Dominika";
    } else if (DOM === "21.12") {
        nameday = "Tomasza, Tomisława";
    } else if (DOM === "22.12") {
        nameday = "Zenona, Honoraty";
    } else if (DOM === "23.12") {
        nameday = "Wiktorii, Sławomiry";
    } else if (DOM === "24.12") {
        nameday = "Adama, Ewy";
    } else if (DOM === "25.12") {
        nameday = "Anastazji, Natana";
    } else if (DOM === "26.12") {
        nameday = "Dionizego, Szczepana";
    } else if (DOM === "27.12") {
        nameday = "Cezarego, Teodora";
    } else if (DOM === "28.12") {
        nameday = "Teofila, Godzisława";
    } else if (DOM === "29.12") {
        nameday = "Dawida, Tomasza";
    } else if (DOM === "30.12") {
        nameday = "Irmy, Eugeniusza";
    } else if (DOM === "31.12") {
        nameday = "Sylwestra, Melanii";
    }


    if(weekday === 0) {
        weekday = "Niedziela"
    } else if (weekday === 1) {
        weekday = "Poniedziałek"
    } else if (weekday === 2) {
        weekday = "Wtorek"
    } else if (weekday === 3) {
        weekday = "Środa"
    } else if (weekday === 4) {
        weekday = "Czwartek"
    } else if (weekday === 5) {
        weekday = "Piątek"
    } else if (weekday === 6) {
        weekday = "Sobota"
    }

    var scrooltext = document.getElementById("date-text")

    scrooltext.innerHTML = "Dzisiaj jest:"+weekday+", "+day+"."+month+"."+year+", "+"Imieniny:"+nameday
}

function loadMsg() {
    var url = "https://piraxu.github.io/Mzp.App/Popup_alert.json?nocache=" + Date.now();

    try {
        var xhr = new ActiveXObject("MSXML2.XMLHTTP");
        xhr.open("GET", url, false);

       
        xhr.setRequestHeader("Cache-Control", "no-cache");
        xhr.setRequestHeader("Pragma", "no-cache");

        xhr.send();

        if (xhr.status == 200) {
            var data = JSON.parse(xhr.responseText);

           
            if (data.content && data.content.trim() !== "") {
                document.getElementById("msg").innerText = data.content;
                document.getElementById("msg").style.display = "block";
            }
        }
    }
    catch (e) {
      
    }

    Msgdetect();
}

function Msgdetect() {
  var mcontent=document.getElementById("msg")
  var Wrp=document.getElementById("wrapper")
  var popup_win=document.getElementById("popup-window")
    if (mcontent.innerHTML==="") {
      Wrp.style.opacity = 1
      popup_win.style.display = "none"
    } else {
      Wrp.style.opacity = 0.2
      popup_win.style.display = "block"
    }
      
    
}

function cPopup() {
    var Wrp=document.getElementById("wrapper")
  var popup_win=document.getElementById("popup-window")
  
  popup_win.style.display= "none"
  Wrp.style.opacity=1
}

// SIG // Begin signature block
// SIG // MIIdRQYJKoZIhvcNAQcCoIIdNjCCHTICAQExDzANBglg
// SIG // hkgBZQMEAgEFADB3BgorBgEEAYI3AgEEoGkwZzAyBgor
// SIG // BgEEAYI3AgEeMCQCAQEEEBDgyQbOONQRoqMAEEvTUJAC
// SIG // AQACAQACAQACAQACAQAwMTANBglghkgBZQMEAgEFAAQg
// SIG // tFAiQcYlo1dvGXSA4gxN6nRbnjCcs6o3SLewuoaqtVOg
// SIG // ghcoMIID6jCCAtKgAwIBAgIQOTcM87ENqadJ2ajqhwXU
// SIG // cDANBgkqhkiG9w0BAQsFADCBjDELMAkGA1UEBhMCUEwx
// SIG // EDAOBgNVBAcMB8WBw7NkxboxIDAeBgNVBAoMF1YtZmly
// SIG // bWEgTVpQIE9TVFJPxYHEmEtBMSMwIQYJKoZIhvcNAQkB
// SIG // FhRrYWxpc3oucDg3QGdtYWlsLmNvbTEkMCIGA1UEAwwb
// SIG // UHJ6ZW15c8WCYXcgS2FsaXN6IChQaXJheHUpMB4XDTI2
// SIG // MDQwNjEwNTYzMloXDTMxMDQwNjExMDYzM1owgYwxCzAJ
// SIG // BgNVBAYTAlBMMRAwDgYDVQQHDAfFgcOzZMW6MSAwHgYD
// SIG // VQQKDBdWLWZpcm1hIE1aUCBPU1RST8WBxJhLQTEjMCEG
// SIG // CSqGSIb3DQEJARYUa2FsaXN6LnA4N0BnbWFpbC5jb20x
// SIG // JDAiBgNVBAMMG1ByemVteXPFgmF3IEthbGlzeiAoUGly
// SIG // YXh1KTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
// SIG // ggEBAPCh2z59PZZF+nVN37dC0QC4Bjq6MlFBEZqWBBbP
// SIG // QjsS3/dqHgB83PmBeAcAWTuSnOECdVqXRcjf7qIR8xjq
// SIG // Qhyl0Zdp4uxHC65leMazeTiohWHVb2BKpUQMEUQFholM
// SIG // dR7DXYdChzfvCHD9RNUo+ERWbGGuNQzoLzI7d5DmeiW0
// SIG // NhrjOosloTfTWxyLQnYPTCib+CXGdJNRkc3lC7lDQ5yJ
// SIG // y4pVTcw3vIxs8lEhzocsygjZ4uBPg0TswGD9Rut9AZWo
// SIG // JqXbnOVTsjJdAJ9i2M5ZZqPXHfySRPpiXYVlGGWOFWz3
// SIG // 7r9nkDoni0wSglzbQdZjJokgEbeM7h8eru0tC9UCAwEA
// SIG // AaNGMEQwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
// SIG // CCsGAQUFBwMDMB0GA1UdDgQWBBSLFdfeAhpCrbWdPw28
// SIG // ozu2eBhyczANBgkqhkiG9w0BAQsFAAOCAQEA4iVfEwxg
// SIG // R5ncss+D36bSNiWvQ6aa/N3LGuuAK4O4KjWyx6aOGEzk
// SIG // w1AtGNx36/Psj7tIktbEhLO1NXf+yhIFQNGVvYlSTd5d
// SIG // 12+0arvgJ588ETxq4PwHCAN62JhiaEdz2dh8hQmQ2fMF
// SIG // uc7nLSRearsyejo2LIGxBLMz+TS9DmIxTgUurNjA8cJw
// SIG // jfEq6Zi1zhDFv5my4mZAzxv3MkeoptvRXjRLALn/zcBN
// SIG // oD3O5C4wFQHeJsNBCAK5SyMk1s+J1Qlylsci3vkgF7I3
// SIG // VLtWL8EVoVQ1Q998TAeJ9Te6QPjNncRzjjtGrc0V6Kmj
// SIG // ZWOXvDZRik5/7eBJhCO0tL3pLDCCBY0wggR1oAMCAQIC
// SIG // EA6bGI750C3n79tQ4ghAGFowDQYJKoZIhvcNAQEMBQAw
// SIG // ZTELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0
// SIG // IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEk
// SIG // MCIGA1UEAxMbRGlnaUNlcnQgQXNzdXJlZCBJRCBSb290
// SIG // IENBMB4XDTIyMDgwMTAwMDAwMFoXDTMxMTEwOTIzNTk1
// SIG // OVowYjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lD
// SIG // ZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNv
// SIG // bTEhMB8GA1UEAxMYRGlnaUNlcnQgVHJ1c3RlZCBSb290
// SIG // IEc0MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKC
// SIG // AgEAv+aQc2jeu+RdSjwwIjBpM+zCpyUuySE98orYWcLh
// SIG // Kac9WKt2ms2uexuEDcQwH/MbpDgW61bGl20dq7J58soR
// SIG // 0uRf1gU8Ug9SH8aeFaV+vp+pVxZZVXKvaJNwwrK6dZlq
// SIG // czKU0RBEEC7fgvMHhOZ0O21x4i0MG+4g1ckgHWMpLc7s
// SIG // Xk7Ik/ghYZs06wXGXuxbGrzryc/NrDRAX7F6Zu53yEio
// SIG // ZldXn1RYjgwrt0+nMNlW7sp7XeOtyU9e5TXnMcvak17c
// SIG // jo+A2raRmECQecN4x7axxLVqGDgDEI3Y1DekLgV9iPWC
// SIG // PhCRcKtVgkEy19sEcypukQF8IUzUvK4bA3VdeGbZOjFE
// SIG // mjNAvwjXWkmkwuapoGfdpCe8oU85tRFYF/ckXEaPZPfB
// SIG // aYh2mHY9WV1CdoeJl2l6SPDgohIbZpp0yt5LHucOY67m
// SIG // 1O+SkjqePdwA5EUlibaaRBkrfsCUtNJhbesz2cXfSwQA
// SIG // zH0clcOP9yGyshG3u3/y1YxwLEFgqrFjGESVGnZifvaA
// SIG // sPvoZKYz0YkH4b235kOkGLimdwHhD5QMIR2yVCkliWzl
// SIG // DlJRR3S+Jqy2QXXeeqxfjT/JvNNBERJb5RBQ6zHFynIW
// SIG // IgnffEx1P2PsIV/EIFFrb7GrhotPwtZFX50g/KEexcCP
// SIG // orF+CiaZ9eRpL5gdLfXZqbId5RsCAwEAAaOCATowggE2
// SIG // MA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFOzX44LS
// SIG // cV1kTN8uZz/nupiuHA9PMB8GA1UdIwQYMBaAFEXroq/0
// SIG // ksuCMS1Ri6enIZ3zbcgPMA4GA1UdDwEB/wQEAwIBhjB5
// SIG // BggrBgEFBQcBAQRtMGswJAYIKwYBBQUHMAGGGGh0dHA6
// SIG // Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBDBggrBgEFBQcwAoY3
// SIG // aHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lD
// SIG // ZXJ0QXNzdXJlZElEUm9vdENBLmNydDBFBgNVHR8EPjA8
// SIG // MDqgOKA2hjRodHRwOi8vY3JsMy5kaWdpY2VydC5jb20v
// SIG // RGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3JsMBEGA1Ud
// SIG // IAQKMAgwBgYEVR0gADANBgkqhkiG9w0BAQwFAAOCAQEA
// SIG // cKC/Q1xV5zhfoKN0Gz22Ftf3v1cHvZqsoYcs7IVeqRq7
// SIG // IviHGmlUIu2kiHdtvRoU9BNKei8ttzjv9P+Aufih9/Jy
// SIG // 3iS8UgPITtAq3votVs/59PesMHqai7Je1M/RQ0SbQyHr
// SIG // lnKhSLSZy51PpwYDE3cnRNTnf+hZqPC/Lwum6fI0POz3
// SIG // A8eHqNJMQBk1RmppVLC4oVaO7KTVPeix3P0c2PR3WlxU
// SIG // jG/voVA9/HYJaISfb8rbII01YBwCA8sgsKxYoA5AY8WY
// SIG // IsGyWfVVa88nq2x2zm8jLfR+cWojayL/ErhULSd+2DrZ
// SIG // 8LaHlv1b0VysGMNNn3O3AamfV6peKOK5lDCCBrQwggSc
// SIG // oAMCAQICEA3HrFcF/yGZLkBDIgw6SYYwDQYJKoZIhvcN
// SIG // AQELBQAwYjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERp
// SIG // Z2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0
// SIG // LmNvbTEhMB8GA1UEAxMYRGlnaUNlcnQgVHJ1c3RlZCBS
// SIG // b290IEc0MB4XDTI1MDUwNzAwMDAwMFoXDTM4MDExNDIz
// SIG // NTk1OVowaTELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRp
// SIG // Z2lDZXJ0LCBJbmMuMUEwPwYDVQQDEzhEaWdpQ2VydCBU
// SIG // cnVzdGVkIEc0IFRpbWVTdGFtcGluZyBSU0E0MDk2IFNI
// SIG // QTI1NiAyMDI1IENBMTCCAiIwDQYJKoZIhvcNAQEBBQAD
// SIG // ggIPADCCAgoCggIBALR4MdMKmEFyvjxGwBysddujRmh0
// SIG // tFEXnU2tjQ2UtZmWgyxU7UNqEY81FzJsQqr5G7A6c+Gh
// SIG // /qm8Xi4aPCOo2N8S9SLrC6Kbltqn7SWCWgzbNfiR+2fk
// SIG // HUiljNOqnIVD/gG3SYDEAd4dg2dDGpeZGKe+42DFUF0m
// SIG // R/vtLa4+gKPsYfwEu7EEbkC9+0F2w4QJLVSTEG8yAR2C
// SIG // QWIM1iI5PHg62IVwxKSpO0XaF9DPfNBKS7Zazch8NF5v
// SIG // p7eaZ2CVNxpqumzTCNSOxm+SAWSuIr21Qomb+zzQWKhx
// SIG // KTVVgtmUPAW35xUUFREmDrMxSNlr/NsJyUXzdtFUUt4a
// SIG // S4CEeIY8y9IaaGBpPNXKFifinT7zL2gdFpBP9qh8SdLn
// SIG // Eut/GcalNeJQ55IuwnKCgs+nrpuQNfVmUB5KlCX3ZA4x
// SIG // 5HHKS+rqBvKWxdCyQEEGcbLe1b8Aw4wJkhU1JrPsFfxW
// SIG // 1gaou30yZ46t4Y9F20HHfIY4/6vHespYMQmUiote8lad
// SIG // jS/nJ0+k6MvqzfpzPDOy5y6gqztiT96Fv/9bH7mQyogx
// SIG // G9QEPHrPV6/7umw052AkyiLA6tQbZl1KhBtTasySkuJD
// SIG // psZGKdlsjg4u70EwgWbVRSX1Wd4+zoFpp4Ra+MlKM2ba
// SIG // oD6x0VR4RjSpWM8o5a6D8bpfm4CLKczsG7ZrIGNTAgMB
// SIG // AAGjggFdMIIBWTASBgNVHRMBAf8ECDAGAQH/AgEAMB0G
// SIG // A1UdDgQWBBTvb1NK6eQGfHrK4pBW9i/USezLTjAfBgNV
// SIG // HSMEGDAWgBTs1+OC0nFdZEzfLmc/57qYrhwPTzAOBgNV
// SIG // HQ8BAf8EBAMCAYYwEwYDVR0lBAwwCgYIKwYBBQUHAwgw
// SIG // dwYIKwYBBQUHAQEEazBpMCQGCCsGAQUFBzABhhhodHRw
// SIG // Oi8vb2NzcC5kaWdpY2VydC5jb20wQQYIKwYBBQUHMAKG
// SIG // NWh0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdp
// SIG // Q2VydFRydXN0ZWRSb290RzQuY3J0MEMGA1UdHwQ8MDow
// SIG // OKA2oDSGMmh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9E
// SIG // aWdpQ2VydFRydXN0ZWRSb290RzQuY3JsMCAGA1UdIAQZ
// SIG // MBcwCAYGZ4EMAQQCMAsGCWCGSAGG/WwHATANBgkqhkiG
// SIG // 9w0BAQsFAAOCAgEAF877FoAc/gc9EXZxML2+C8i1NKZ/
// SIG // zdCHxYgaMH9Pw5tcBnPw6O6FTGNpoV2V4wzSUGvI9NAz
// SIG // aoQk97frPBtIj+ZLzdp+yXdhOP4hCFATuNT+ReOPK0mC
// SIG // efSG+tXqGpYZ3essBS3q8nL2UwM+NMvEuBd/2vmdYxDC
// SIG // vwzJv2sRUoKEfJ+nN57mQfQXwcAEGCvRR2qKtntujB71
// SIG // WPYAgwPyWLKu6RnaID/B0ba2H3LUiwDRAXx1Neq9ydOa
// SIG // l95CHfmTnM4I+ZI2rVQfjXQA1WSjjf4J2a7jLzWGNqNX
// SIG // +DF0SQzHU0pTi4dBwp9nEC8EAqoxW6q17r0z0noDjs6+
// SIG // BFo+z7bKSBwZXTRNivYuve3L2oiKNqetRHdqfMTCW/Nm
// SIG // KLJ9M+MtucVGyOxiDf06VXxyKkOirv6o02OoXN4bFzK0
// SIG // vlNMsvhlqgF2puE6FndlENSmE+9JGYxOGLS/D284NHNb
// SIG // oDGcmWXfwXRy4kbu4QFhOm0xJuF2EZAOk5eCkhSxZON3
// SIG // rGlHqhpB/8MluDezooIs8CVnrpHMiD2wL40mm53+/j7t
// SIG // FaxYKIqL0Q4ssd8xHZnIn/7GELH3IdvG2XlM9q7WP/Uw
// SIG // gOkw/HQtyRN62JK4S1C8uw3PdBunvAZapsiI5YKdvlar
// SIG // Evf8EA+8hcpSM9LHJmyrxaFtoza2zNaQ9k+5t1wwggbt
// SIG // MIIE1aADAgECAhAKgO8YS43xBYLRxHanlXRoMA0GCSqG
// SIG // SIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQK
// SIG // Ew5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNl
// SIG // cnQgVHJ1c3RlZCBHNCBUaW1lU3RhbXBpbmcgUlNBNDA5
// SIG // NiBTSEEyNTYgMjAyNSBDQTEwHhcNMjUwNjA0MDAwMDAw
// SIG // WhcNMzYwOTAzMjM1OTU5WjBjMQswCQYDVQQGEwJVUzEX
// SIG // MBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNVBAMT
// SIG // MkRpZ2lDZXJ0IFNIQTI1NiBSU0E0MDk2IFRpbWVzdGFt
// SIG // cCBSZXNwb25kZXIgMjAyNSAxMIICIjANBgkqhkiG9w0B
// SIG // AQEFAAOCAg8AMIICCgKCAgEA0EasLRLGntDqrmBWsytX
// SIG // um9R/4ZwCgHfyjfMGUIwYzKomd8U1nH7C8Dr0cVMF3Bs
// SIG // fAFI54um8+dnxk36+jx0Tb+k+87H9WPxNyFPJIDZHhAq
// SIG // lUPt281mHrBbZHqRK71Em3/hCGC5KyyneqiZ7syvFXJ9
// SIG // A72wzHpkBaMUNg7MOLxI6E9RaUueHTQKWXymOtRwJXcr
// SIG // cTTPPT2V1D/+cFllESviH8YjoPFvZSjKs3SKO1QNUdFd
// SIG // 2adw44wDcKgH+JRJE5Qg0NP3yiSyi5MxgU6cehGHr7zo
// SIG // u1znOM8odbkqoK+lJ25LCHBSai25CFyD23DZgPfDrJJJ
// SIG // K77epTwMP6eKA0kWa3osAe8fcpK40uhktzUd/Yk0xUvh
// SIG // DU6lvJukx7jphx40DQt82yepyekl4i0r8OEps/FNO4ah
// SIG // fvAk12hE5FVs9HVVWcO5J4dVmVzix4A77p3awLbr89A9
// SIG // 0/nWGjXMGn7FQhmSlIUDy9Z2hSgctaepZTd0ILIUbWuh
// SIG // KuAeNIeWrzHKYueMJtItnj2Q+aTyLLKLM0MheP/9w6Ct
// SIG // juuVHJOVoIJ/DtpJRE7Ce7vMRHoRon4CWIvuiNN1Lk9Y
// SIG // +xZ66lazs2kKFSTnnkrT3pXWETTJkhd76CIDBbTRofOs
// SIG // NyEhzZtCGmnQigpFHti58CSmvEyJcAlDVcKacJ+A9/z7
// SIG // eacCAwEAAaOCAZUwggGRMAwGA1UdEwEB/wQCMAAwHQYD
// SIG // VR0OBBYEFOQ7/PIx7f391/ORcWMZUEPPYYzoMB8GA1Ud
// SIG // IwQYMBaAFO9vU0rp5AZ8esrikFb2L9RJ7MtOMA4GA1Ud
// SIG // DwEB/wQEAwIHgDAWBgNVHSUBAf8EDDAKBggrBgEFBQcD
// SIG // CDCBlQYIKwYBBQUHAQEEgYgwgYUwJAYIKwYBBQUHMAGG
// SIG // GGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBdBggrBgEF
// SIG // BQcwAoZRaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29t
// SIG // L0RpZ2lDZXJ0VHJ1c3RlZEc0VGltZVN0YW1waW5nUlNB
// SIG // NDA5NlNIQTI1NjIwMjVDQTEuY3J0MF8GA1UdHwRYMFYw
// SIG // VKBSoFCGTmh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9E
// SIG // aWdpQ2VydFRydXN0ZWRHNFRpbWVTdGFtcGluZ1JTQTQw
// SIG // OTZTSEEyNTYyMDI1Q0ExLmNybDAgBgNVHSAEGTAXMAgG
// SIG // BmeBDAEEAjALBglghkgBhv1sBwEwDQYJKoZIhvcNAQEL
// SIG // BQADggIBAGUqrfEcJwS5rmBB7NEIRJ5jQHIh+OT2Ik/b
// SIG // NYulCrVvhREafBYF0RkP2AGr181o2YWPoSHz9iZEN/FP
// SIG // sLSTwVQWo2H62yGBvg7ouCODwrx6ULj6hYKqdT8wv2UV
// SIG // +Kbz/3ImZlJ7YXwBD9R0oU62PtgxOao872bOySCILdBg
// SIG // hQ/ZLcdC8cbUUO75ZSpbh1oipOhcUT8lD8QAGB9lctZT
// SIG // TOJM3pHfKBAEcxQFoHlt2s9sXoxFizTeHihsQyfFg5fx
// SIG // UFEp7W42fNBVN4ueLaceRf9Cq9ec1v5iQMWTFQa0xNqI
// SIG // tH3CPFTG7aEQJmmrJTV3Qhtfparz+BW60OiMEgV5GWoB
// SIG // y4RVPRwqxv7Mk0Sy4QHs7v9y69NBqycz0BZwhB9WOfOu
// SIG // /CIJnzkQTwtSSpGGhLdjnQ4eBpjtP+XB3pQCtv4E5UCS
// SIG // Dag6+iX8MmB10nfldPF9SVD7weCC3yXZi/uuhqdwkgVx
// SIG // uiMFzGVFwYbQsiGnoa9F5AaAyBjFBtXVLcKtapnMG3VH
// SIG // 3EmAp/jsJ3FVF3+d1SVDTmjFjLbNFZUWMXuZyvgLfgyP
// SIG // ehwJVxwC+UpX2MSey2ueIu9THFVkT+um1vshETaWyQo8
// SIG // gmBto/m3acaP9QsuLj3FNwFlTxq25+T4QwX9xa6ILs84
// SIG // ZPvmpovq90K8eWyG2N01c4IhSOxqt81nMYIFdTCCBXEC
// SIG // AQEwgaEwgYwxCzAJBgNVBAYTAlBMMRAwDgYDVQQHDAfF
// SIG // gcOzZMW6MSAwHgYDVQQKDBdWLWZpcm1hIE1aUCBPU1RS
// SIG // T8WBxJhLQTEjMCEGCSqGSIb3DQEJARYUa2FsaXN6LnA4
// SIG // N0BnbWFpbC5jb20xJDAiBgNVBAMMG1ByemVteXPFgmF3
// SIG // IEthbGlzeiAoUGlyYXh1KQIQOTcM87ENqadJ2ajqhwXU
// SIG // cDANBglghkgBZQMEAgEFAKB8MBAGCisGAQQBgjcCAQwx
// SIG // AjAAMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwG
// SIG // CisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
// SIG // SIb3DQEJBDEiBCCuP52ZgMIH19pTvJ1m/a9hIU63yWv8
// SIG // WwZCMjbpCnrY1zANBgkqhkiG9w0BAQEFAASCAQAKIVbm
// SIG // Vx6yXyj55Se05BCXw+w96j9xgyjoc7gdXIkjKKCgPERa
// SIG // x9qkTI2uqFpHasRLMaRt8oLMW5cjtCvWTuNzliRkSQac
// SIG // hz93pQoEV0HjLJjXH+eHyAre++fniMPwxTPgcezn/OCp
// SIG // ICM8bRMi24SK3alkxdHZZ+N4O2OXJRJ26FmxoI5yIEMs
// SIG // NfPnq034I+chzx4/MRq7QUFh12YxWuhsf5IxvASv6zjV
// SIG // cnj/21x253Bc5qUQC8w/Cp1dTVXZg2IADEkReqa9jFaC
// SIG // xpeqGZRp7Uj+Qlw4ji3W4WIbNacAlom4AI1DU/TFFuoB
// SIG // InV7jdPhQ1fQ4ux1piarLJvTMDfvoYIDJjCCAyIGCSqG
// SIG // SIb3DQEJBjGCAxMwggMPAgEBMH0waTELMAkGA1UEBhMC
// SIG // VVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMUEwPwYD
// SIG // VQQDEzhEaWdpQ2VydCBUcnVzdGVkIEc0IFRpbWVTdGFt
// SIG // cGluZyBSU0E0MDk2IFNIQTI1NiAyMDI1IENBMQIQCoDv
// SIG // GEuN8QWC0cR2p5V0aDANBglghkgBZQMEAgEFAKBpMBgG
// SIG // CSqGSIb3DQEJAzELBgkqhkiG9w0BBwEwHAYJKoZIhvcN
// SIG // AQkFMQ8XDTI2MDQwNjExMTEyMVowLwYJKoZIhvcNAQkE
// SIG // MSIEIDRjpbaek9zlkERm8WgakLAYpP63zeO40AWA1btx
// SIG // QV9gMA0GCSqGSIb3DQEBAQUABIICAEElRj1yBfi1pn30
// SIG // ELNU5IvxXe9epF5ELd0VPeoebWavIxAaCXy3AloR9YG/
// SIG // w511jmpzz+Vbsi84Qer8JRJbWBn+i9vkMN3mjRcg5VQz
// SIG // GAAsUrU0Saoxa4uywS2qx7QnrqO40ae4N0YumvdWy9js
// SIG // /H3PY2r6fS/YLlHDg9DBJt116Li4ya1bG1FC/ZD9EWPF
// SIG // ABW1+Dgqbv2CdfSEUTcZmH3RCLKurS2+O7nb3colsWnC
// SIG // 92nF01B62qIJY9o6M0Wtb+oH1Oe04zyoTU17OT7ecv7A
// SIG // AZUx8xPb1X1doY98l7PvQLHXyZ5hb7OjhzEfY/nj3cH7
// SIG // nGzWgZWt0gkizJWIcW72+Vu8Ic08l5WS1XSG0tbuIdMs
// SIG // zLvIo/HMoBcqNqOMcYzhKPDaO4j9ZWXMzePCQv83Cl0Z
// SIG // jMDCAt0LSqGZheU/cmOozllwvXALGEyyni9VCT3iGCM9
// SIG // ML/fYjDBmh0w9PEASwQKla4NfPB/iFAEh3oXuX86iTkb
// SIG // vUV/pD9klH1+hwKFcVf6KP8wzKpX0nbsq98sHasQuFOG
// SIG // 9YwfCZSgZlC5QZHeg9YUgV/kcHot/TEA0gRhHHzWrZAv
// SIG // NrkWyMbnhnrozWmtimtZptafshy7nnuZWJgex71lSxGj
// SIG // 1rOylGjo1M83Pau7NXjvb/yx7L4a4JZuE/oyWgUBxt8j
// SIG // CSi+1NJC
// SIG // End signature block
