  document.oncontextmenu = function() {
    return false;
};


function titlechange() {
        var apptitle = document.getElementById("chtitle")
        if(apptitle.innerText === "MZP APP - Wybierz Rozkład") {
apptitle.innerHTML = "Szczęśliwego nowego 2026 roku !"
        } else {
            apptitle.innerText = "MZP APP - Wybierz Rozkład"
        }

        setTimeout(titlechange,5000)
}

function setwindow() {
            var szerokosc = 1006;
            var wysokosc = 518;
            window.resizeTo(szerokosc, wysokosc);
            window.moveTo(
                (screen.availWidth - szerokosc) / 2,
                (screen.availHeight - wysokosc) / 2
            );
}

function enforceWindowSize() {
            var szerokosc = 1006;
            var wysokosc = 518;

            if (window.outerWidth !== szerokosc || window.outerHeight !== wysokosc) {
                window.resizeTo(szerokosc, wysokosc);
                window.moveTo(
                    (screen.availWidth - szerokosc) / 2,
                    (screen.availHeight - wysokosc) / 2
                );
            }
}


function loadsettings() {
    var theme = readFile("properties//theme.prop")
    var cssheet = document.getElementById("css")

if(theme === "dark") {
cssheet.href = "resources/css/D_Main.css"
} else {
    cssheet.href = "resources/css/L_Main.css"
}

var popup = readFile("properties/popup.prop")

if(popup === "true") {
    loadMsg();
} else {
    return;
}

}

function clock() {
  var today = new Date();
  var h = today.getHours();
  var m = today.getMinutes();
  var s = today.getSeconds();
  if(h<10) h = "0"+h
  if(m<10) m = "0"+m
  if(s<10) s = "0"+s

  document.getElementById("hour").innerHTML = h;
  document.getElementById("minute").innerHTML = m;
  document.getElementById("secound").innerHTML = s;

  setTimeout(clock,1000);
}

function nameday() {
    var now = new Date();
    var day = now.getDate();
    var month = now.getMonth()+1;
    var weekday = now.getDay();
    var year = now.getFullYear();
    if(day<10) day = "0"+day
    if(month<10) month = "0"+month
    var DOM = day+"."+month;
    var nameday = ""
    

if (DOM === "01.01") {
        nameday = "Mieszka, Mieczysława";
    } else if (DOM === "02.01") {
        nameday = "Izydora, Grzegorza";
    } else if (DOM === "03.01") {
        nameday = "Danuty, Genowefy";
    } else if (DOM === "04.01") {
        nameday = "Elżbiety, Anieli";
    } else if (DOM === "05.01") {
        nameday = "Hanny, Edwarda";
    } else if (DOM === "06.01") {
        nameday = "Kacpra, Melchiora";
    } else if (DOM === "07.01") {
        nameday = "Lucjana, Juliana";
    } else if (DOM === "08.01") {
        nameday = "Seweryna, Teofila";
    } else if (DOM === "09.01") {
        nameday = "Adriana, Alicji";
    } else if (DOM === "10.01") {
        nameday = "Jana, Wilhelma";
    } else if (DOM === "11.01") {
        nameday = "Honoraty, Matyldy";
    } else if (DOM === "12.01") {
        nameday = "Benedykta, Arkadiusza";
    } else if (DOM === "13.01") {
        nameday = "Bogumiły, Weroniki";
    } else if (DOM === "14.01") {
        nameday = "Feliksa, Niny";
    } else if (DOM === "15.01") {
        nameday = "Pawła, Arnolda";
    } else if (DOM === "16.01") {
        nameday = "Marcelego, Włodzimierza";
    } else if (DOM === "17.01") {
        nameday = "Antoniego, Jana";
    } else if (DOM === "18.01") {
        nameday = "Małgorzaty, Piotra";
    } else if (DOM === "19.01") {
        nameday = "Henryka, Marty";
    } else if (DOM === "20.01") {
        nameday = "Fabiana, Sebastiana";
    } else if (DOM === "21.01") {
        nameday = "Agnieszki, Jarosława";
    } else if (DOM === "22.01") {
        nameday = "Anastazego, Wincentego";
    } else if (DOM === "23.01") {
        nameday = "Iidelfonsa, Rajmunda";
    } else if (DOM === "24.01") {
        nameday = "Rafała, Felicji";
    } else if (DOM === "25.01") {
        nameday = "Pawła, Miłosza";
    } else if (DOM === "26.01") {
        nameday = "Pauliny, Tymoteusza";
    } else if (DOM === "27.01") {
        nameday = "Przybysława, Jana";
    } else if (DOM === "28.01") {
        nameday = "Radomira, Walerego";
    } else if (DOM === "29.01") {
        nameday = "Bolesławy, Franciszka";
    } else if (DOM === "30.01") {
        nameday = "Macieja, Martyny";
    } else if (DOM === "31.01") {
        nameday = "Marceli, Jana";
    } else if (DOM === "01.02") {
        nameday = "Brygidy, Ignacego";
    } else if (DOM === "02.02") {
        nameday = "Marii, Mirosława";
    } else if (DOM === "03.02") {
        nameday = "Błażeja, Oskara";
    } else if (DOM === "04.02") {
        nameday = "Weroniki, Żanety";
    } else if (DOM === "05.02") {
        nameday = "Agaty, Adelajdy";
    } else if (DOM === "06.02") {
        nameday = "Doroty, Tytusa";
    } else if (DOM === "07.02") {
        nameday = "Ryszarda, Teodora";
    } else if (DOM === "08.02") {
        nameday = "Jana, Piotra";
    } else if (DOM === "09.02") {
        nameday = "Apolonii, Eryki";
    } else if (DOM === "10.02") {
        nameday = "Jacka, Scholastyki";
    } else if (DOM === "11.02") {
        nameday = "Łazarza, Marii";
    } else if (DOM === "12.02") {
        nameday = "Eulalii, Modesta";
    } else if (DOM === "13.02") {
        nameday = "Grzegorza, Katarzyny";
    } else if (DOM === "14.02") {
        nameday = "Metodego, Walentego";
    } else if (DOM === "15.02") {
        nameday = "Jowity, Faustyny";
    } else if (DOM === "16.02") {
        nameday = "Danuty, Juliany";
    } else if (DOM === "17.02") {
        nameday = "Aleksandra, Łukasza";
    } else if (DOM === "18.02") {
        nameday = "Szymona, Konstancji";
    } else if (DOM === "19.02") {
        nameday = "Arnolda, Józefa";
    } else if (DOM === "20.02") {
        nameday = "Leona, Ludomira";
    } else if (DOM === "21.02") {
        nameday = "Roberta, Eleonory";
    } else if (DOM === "22.02") {
        nameday = "Marty, Małgorzaty";
    } else if (DOM === "23.02") {
        nameday = "Romany, Damiana";
    } else if (DOM === "24.02") {
        nameday = "Macieja, Marka";
    } else if (DOM === "25.02") {
        nameday = "Cezarego, Donata";
    } else if (DOM === "26.02") {
        nameday = "Mirosława, Aleksandra";
    } else if (DOM === "27.02") {
        nameday = "Gabriela, Anastazji";
    } else if (DOM === "28.02") {
        nameday = "Romana, Makarego";
    } else if (DOM === "29.02") {
        nameday = "Antonia, Augusta"
    }
     else if (DOM === "01.03") {
        nameday = "Radosława, Antoniego";
    } else if (DOM === "02.03") {
        nameday = "Heleny, Pawła";
    } else if (DOM === "03.03") {
        nameday = "Tycjana, Kunegundy";
    } else if (DOM === "04.03") {
        nameday = "Kazimierza, Łucji";
    } else if (DOM === "05.03") {
        nameday = "Oliwii, Adriana";
    } else if (DOM === "06.03") {
        nameday = "Róży, Wiktora";
    } else if (DOM === "07.03") {
        nameday = "Pawła, Tomasza";
    } else if (DOM === "08.03") {
        nameday = "Beaty, Wincentego";
    } else if (DOM === "09.03") {
        nameday = "Franciszki, Katarzyny";
    } else if (DOM === "10.03") {
        nameday = "Cypriana, Aleksandra";
    } else if (DOM === "11.03") {
        nameday = "Benedykta, Konstantego";
    } else if (DOM === "12.03") {
        nameday = "Bernarda, Grzegorza";
    } else if (DOM === "13.03") {
        nameday = "Bożeny, Krystyny";
    } else if (DOM === "14.03") {
        nameday = "Leona, Matyldy";
    } else if (DOM === "15.03") {
        nameday = "Longina, Klemensa";
    } else if (DOM === "16.03") {
        nameday = "Izabeli, Hilarego";
    } else if (DOM === "17.03") {
        nameday = "Patryka, Zbigniewa";
    } else if (DOM === "18.03") {
        nameday = "Cyryla, Edwarda";
    } else if (DOM === "19.03") {
        nameday = "Józefa, Bogdana";
    } else if (DOM === "20.03") {
        nameday = "Klaudii, Eufemii";
    } else if (DOM === "21.03") {
        nameday = "Ludomira, Benedykta";
    } else if (DOM === "22.03") {
        nameday = "Katarzyny, Bogusława";
    } else if (DOM === "23.03") {
        nameday = "Pelagii, Feliksa";
    } else if (DOM === "24.03") {
        nameday = "Marka, Gabriela";
    } else if (DOM === "25.03") {
        nameday = "Marioli, Wieńczysława";
    } else if (DOM === "26.03") {
        nameday = "Emanuela, Larysy";
    } else if (DOM === "27.03") {
        nameday = "Lidii, Ernesta";
    } else if (DOM === "28.03") {
        nameday = "Anieli, Jana";
    } else if (DOM === "29.03") {
        nameday = "Wiktoryny, Eustachego";
    } else if (DOM === "30.03") {
        nameday = "Amelii, Leonarda";
    } else if (DOM === "31.03") {
        nameday = "Beniamina, Balbiny";
    } else if (DOM === "01.04") {
        nameday = "Grażyny, Ireny";
    } else if (DOM === "02.04") {
        nameday = "Władysława, Franciszka";
    } else if (DOM === "03.04") {
        nameday = "Ryszarda, Pankracego";
    } else if (DOM === "04.04") {
        nameday = "Benedykta, Izydora";
    } else if (DOM === "05.04") {
        nameday = "Katarzyny, Wincentego";
    } else if (DOM === "06.04") {
        nameday = "Izoldy, Ireneusza";
    } else if (DOM === "07.04") {
        nameday = "Hermana, Donata";
    } else if (DOM === "08.04") {
        nameday = "Dionizego, Julii";
    } else if (DOM === "09.04") {
        nameday = "Marii, Dymitra";
    } else if (DOM === "10.04") {
        nameday = "Michała, Makarego";
    } else if (DOM === "11.04") {
        nameday = "Filipa, Leona";
    } else if (DOM === "12.04") {
        nameday = "Dominika, Juliusza";
    } else if (DOM === "13.04") {
        nameday = "Przemysława, Idy";
    } else if (DOM === "14.04") {
        nameday = "Bereniki, Waleriana";
    } else if (DOM === "15.04") {
        nameday = "Anastazji, Bazylego";
    } else if (DOM === "16.04") {
        nameday = "Cecyliana, Bernadety";
    } else if (DOM === "17.04") {
        nameday = "Roberta, Rudolfa";
    } else if (DOM === "18.04") {
        nameday = "Alicji, Bogusławy";
    } else if (DOM === "19.04") {
        nameday = "Adolfa, Tymona";
    } else if (DOM === "20.04") {
        nameday = "Czesława, Agnieszki";
    } else if (DOM === "21.04") {
        nameday = "Bartosza, Feliksa";
    } else if (DOM === "22.04") {
        nameday = "Kai, Łukasza";
    } else if (DOM === "23.04") {
        nameday = "Jerzego, Idziego";
    } else if (DOM === "24.04") {
        nameday = "Aleksego, Horacego";
    } else if (DOM === "25.04") {
        nameday = "Marka, Jarosława";
    } else if (DOM === "26.04") {
        nameday = "Marzeny, Marii";
    } else if (DOM === "27.04") {
        nameday = "Zyty, Teofila";
    } else if (DOM === "28.04") {
        nameday = "Pawła, Walerii";
    } else if (DOM === "29.04") {
        nameday = "Rity, Piotra";
    } else if (DOM === "30.04") {
        nameday = "Mariana, Katarzyny";
    } else if (DOM === "01.05") {
        nameday = "Józefa, Jeremiasza";
    } else if (DOM === "02.05") {
        nameday = "Zygmunta, Anatola";
    } else if (DOM === "03.05") {
        nameday = "Marii, Marioli";
    } else if (DOM === "04.05") {
        nameday = "Moniki, Floriana";
    } else if (DOM === "05.05") {
        nameday = "Ireny, Waldemara";
    } else if (DOM === "06.05") {
        nameday = "Jana, Judyty";
    } else if (DOM === "07.05") {
        nameday = "Gizeli, Ludmiły";
    } else if (DOM === "08.05") {
        nameday = "Lizy, Wiktora";
    } else if (DOM === "09.05") {
        nameday = "Bożydara, Grzegorza";
    } else if (DOM === "10.05") {
        nameday = "Izydora, Antoniny";
    } else if (DOM === "11.05") {
        nameday = "Igi, Ignacego";
    } else if (DOM === "12.05") {
        nameday = "Joanny, Pankracego";
    } else if (DOM === "13.05") {
        nameday = "Roberta, Serwacego";
    } else if (DOM === "14.05") {
        nameday = "Bonifacego, Dobiesława";
    } else if (DOM === "15.05") {
        nameday = "Zofii, Strzeżysława";
    } else if (DOM === "16.05") {
        nameday = "Andrzeja, Wieńczysława";
    } else if (DOM === "17.05") {
        nameday = "Brunona, Paschalisa";
    } else if (DOM === "18.05") {
        nameday = "Feliksa, Aleksandry";
    } else if (DOM === "19.05") {
        nameday = "Piotra, Mikołaja";
    } else if (DOM === "20.05") {
        nameday = "Aleksandra, Bazylego";
    } else if (DOM === "21.05") {
        nameday = "Jana, Wiktora";
    } else if (DOM === "22.05") {
        nameday = "Heleny, Wiesława";
    } else if (DOM === "23.05") {
        nameday = "Emilii, Iwony";
    } else if (DOM === "24.05") {
        nameday = "Joanny, Zuzanny";
    } else if (DOM === "25.05") {
        nameday = "Urbana, Grzegorza";
    } else if (DOM === "26.05") {
        nameday = "Filipa, Pauliny";
    } else if (DOM === "27.05") {
        nameday = "Augustyna, Juliana";
    } else if (DOM === "28.05") {
        nameday = "Jaromira, Justa";
    } else if (DOM === "29.05") {
        nameday = "Teodozji, Magdaleny";
    } else if (DOM === "30.05") {
        nameday = "Feliksa, Ferdynanda";
    } else if (DOM === "31.05") {
        nameday = "Anieli, Petroneli";
    } else if (DOM === "01.06") {
        nameday = "Jakuba, Konrada";
    } else if (DOM === "02.06") {
        nameday = "Erazma, Marianny";
    } else if (DOM === "03.06") {
        nameday = "Leszka, Tamary";
    } else if (DOM === "04.06") {
        nameday = "Franciszka, Karola";
    } else if (DOM === "05.06") {
        nameday = "Bonifacego, Waltera";
    } else if (DOM === "06.06") {
        nameday = "Norberta, Laurentego";
    } else if (DOM === "07.06") {
        nameday = "Roberta, Wiesława";
    } else if (DOM === "08.06") {
        nameday = "Maksyma, Medarda";
    } else if (DOM === "09.06") {
        nameday = "Anny, Felicjana";
    } else if (DOM === "10.06") {
        nameday = "Bogumiła, Małgorzaty";
    } else if (DOM === "11.06") {
        nameday = "Barnaby, Radomiła";
    } else if (DOM === "12.06") {
        nameday = "Janiny, Jana";
    } else if (DOM === "13.06") {
        nameday = "Lucjana, Antoniego";
    } else if (DOM === "14.06") {
        nameday = "Bazylego, Elizy";
    } else if (DOM === "15.06") {
        nameday = "Wita, Jolanty";
    } else if (DOM === "16.06") {
        nameday = "Aliny, Benona";
    } else if (DOM === "17.06") {
        nameday = "Laury, Adolfa";
    } else if (DOM === "18.06") {
        nameday = "Marka, Elżbiety";
    } else if (DOM === "19.06") {
        nameday = "Gerwazego, Protazego";
    } else if (DOM === "20.06") {
        nameday = "Diny, Bogny";
    } else if (DOM === "21.06") {
        nameday = "Alicji, Alojzego";
    } else if (DOM === "22.06") {
        nameday = "Pauliny, Tomasza";
    } else if (DOM === "23.06") {
        nameday = "Wandy, Zenona";
    } else if (DOM === "24.06") {
        nameday = "Jana, Danuty";
    } else if (DOM === "25.06") {
        nameday = "Łucji, Wilhelma";
    } else if (DOM === "26.06") {
        nameday = "Jana, Pawła";
    } else if (DOM === "27.06") {
        nameday = "Maryli, Władysława";
    } else if (DOM === "28.06") {
        nameday = "Leona, Ireneusza";
    } else if (DOM === "29.06") {
        nameday = "Piotra, Pawła";
    } else if (DOM === "30.06") {
        nameday = "Emilii, Lucyny";
    } else if (DOM === "01.07") {
        nameday = "Haliny, Mariana";
    } else if (DOM === "02.07") {
        nameday = "Jagody, Urbana";
    } else if (DOM === "03.07") {
        nameday = "Jacka, Anatola";
    } else if (DOM === "04.07") {
        nameday = "Malwiny, Teodora";
    } else if (DOM === "05.07") {
        nameday = "Karoliny, Antoniego";
    } else if (DOM === "06.07") {
        nameday = "Dominiki, Gotarda";
    } else if (DOM === "07.07") {
        nameday = "Benedykta, Cyryla";
    } else if (DOM === "08.07") {
        nameday = "Adriany, Eugeniusza";
    } else if (DOM === "09.07") {
        nameday = "Weroniki, Zenona";
    } else if (DOM === "10.07") {
        nameday = "Amelii, Witalisa";
    } else if (DOM === "11.07") {
        nameday = "Olgi, Kaliny";
    } else if (DOM === "12.07") {
        nameday = "Jana, Brunona";
    } else if (DOM === "13.07") {
        nameday = "Ernesta, Małgorzaty";
    } else if (DOM === "14.07") {
        nameday = "Bonawentury, Stelii";
    } else if (DOM === "15.07") {
        nameday = "Włodzimierza, Henryka";
    } else if (DOM === "16.07") {
        nameday = "Benedykta, Marii";
    } else if (DOM === "17.07") {
        nameday = "Anety, Bogdana";
    } else if (DOM === "18.07") {
        nameday = "Kamila, Szymona";
    } else if (DOM === "19.07") {
        nameday = "Wincentego, Wodzisława";
    } else if (DOM === "20.07") {
        nameday = "Czesława, Hieronima";
    } else if (DOM === "21.07") {
        nameday = "Daniela, Dalidy";
    } else if (DOM === "22.07") {
        nameday = "Marii, Magdaleny";
    } else if (DOM === "23.07") {
        nameday = "Bogny, Apolinarego";
    } else if (DOM === "24.07") {
        nameday = "Kingi, Krystyny";
    } else if (DOM === "25.07") {
        nameday = "Jakuba, Krzysztofa";
    } else if (DOM === "26.07") {
        nameday = "Anny, Mirosławy";
    } else if (DOM === "27.07") {
        nameday = "Natalii, Julii";
    } else if (DOM === "28.07") {
        nameday = "Wiktora, Innocentego";
    } else if (DOM === "29.07") {
        nameday = "Olafa, Marty";
    } else if (DOM === "30.07") {
        nameday = "Julity, Piotra";
    } else if (DOM === "31.07") {
        nameday = "Ignacego, Lubomira";
    } else if (DOM === "01.08") {
        nameday = "Alfonsa, Nadii";
    } else if (DOM === "02.08") {
        nameday = "Kariny, Gustawa";
    } else if (DOM === "03.08") {
        nameday = "Lidii, Augusta";
    } else if (DOM === "04.08") {
        nameday = "Dominika, Jana";
    } else if (DOM === "05.08") {
        nameday = "Marii, Oswalda";
    } else if (DOM === "06.08") {
        nameday = "Sławy, Jakuba";
    } else if (DOM === "07.08") {
        nameday = "Klaudii, Kajetana";
    } else if (DOM === "08.08") {
        nameday = "Cyryla, Seweryna";
    } else if (DOM === "09.08") {
        nameday = "Romana, Ryszarda";
    } else if (DOM === "10.08") {
        nameday = "Bogdana, Borysa";
    } else if (DOM === "11.08") {
        nameday = "Zuzanny, Klary";
    } else if (DOM === "12.08") {
        nameday = "Lecha, Euzebii";
    } else if (DOM === "13.08") {
        nameday = "Diany, Hipolita";
    } else if (DOM === "14.08") {
        nameday = "Alfreda, Euzebiusza";
    } else if (DOM === "15.08") {
        nameday = "Marii, Napoleona";
    } else if (DOM === "16.08") {
        nameday = "Stefana, Rocha";
    } else if (DOM === "17.08") {
        nameday = "Anity, Elizy";
    } else if (DOM === "18.08") {
        nameday = "Ilony, Klary";
    } else if (DOM === "19.08") {
        nameday = "Jana, Bolesława";
    } else if (DOM === "20.08") {
        nameday = "Bernarda, Samuela";
    } else if (DOM === "21.08") {
        nameday = "Franciszka, Joanny";
    } else if (DOM === "22.08") {
        nameday = "Marii, Cezarego";
    } else if (DOM === "23.08") {
        nameday = "Filipa, Apolinarego";
    } else if (DOM === "24.08") {
        nameday = "Jerzego, Bartłomieja";
    } else if (DOM === "25.08") {
        nameday = "Luizy, Ludwika";
    } else if (DOM === "26.08") {
        nameday = "Ireneusza, Zefiryny";
    } else if (DOM === "27.08") {
        nameday = "Moniki, Cezarego";
    } else if (DOM === "28.08") {
        nameday = "Patrycji, Wyszomira";
    } else if (DOM === "29.08") {
        nameday = "Sabiny, Jana";
    } else if (DOM === "30.08") {
        nameday = "Róży, Szczęsnego";
    } else if (DOM === "31.08") {
        nameday = "Izabeli, Ramony";
    } else if (DOM === "01.09") {
        nameday = "Bronisława, Idziego";
    } else if (DOM === "02.09") {
        nameday = "Juliana, Stefana";
    } else if (DOM === "03.09") {
        nameday = "Izabeli, Szymona";
    } else if (DOM === "04.09") {
        nameday = "Idy, Lilianny";
    } else if (DOM === "05.09") {
        nameday = "Doroty, Wawrzyńca";
    } else if (DOM === "06.09") {
        nameday = "Beaty, Eugeniusza";
    } else if (DOM === "07.09") {
        nameday = "Reginy, Melchiora";
    } else if (DOM === "08.09") {
        nameday = "Marii, Adrianny";
    } else if (DOM === "09.09") {
        nameday = "Piotra, Sergiusza";
    } else if (DOM === "10.09") {
        nameday = "Łukasza, Mikołaja";
    } else if (DOM === "11.09") {
        nameday = "Jacka, Dagny";
    } else if (DOM === "12.09") {
        nameday = "Radzimira, Gwidona";
    } else if (DOM === "13.09") {
        nameday = "Eugeni, Aureliusza";
    } else if (DOM === "14.09") {
        nameday = "Roksany, Bernarda";
    } else if (DOM === "15.09") {
        nameday = "Albina, Nikodema";
    } else if (DOM === "16.09") {
        nameday = "Edyty, Kornela";
    } else if (DOM === "17.09") {
        nameday = "Franciszka, Hildegardy";
    } else if (DOM === "18.09") {
        nameday = "Irmy, Józefa";
    } else if (DOM === "19.09") {
        nameday = "Januarego, Konstancji";
    } else if (DOM === "20.09") {
        nameday = "Filipiny, Eustachego";
    } else if (DOM === "21.09") {
        nameday = "Jonasza, Mateusza";
    } else if (DOM === "22.09") {
        nameday = "Tomasza, Maurycego";
    } else if (DOM === "23.09") {
        nameday = "Bogusława, Tekli";
    } else if (DOM === "24.09") {
        nameday = "Gerarda, Teodora";
    } else if (DOM === "25.09") {
        nameday = "Aurelii, Władysława";
    } else if (DOM === "26.09") {
        nameday = "Justyny, Cypriana";
    } else if (DOM === "27.09") {
        nameday = "Damiana, Amadeusza";
    } else if (DOM === "28.09") {
        nameday = "Luby, Wacława";
    } else if (DOM === "29.09") {
        nameday = "Michała, Michaliny";
    } else if (DOM === "30.09") {
        nameday = "Wery, Honoriusza";
    } else if (DOM === "01.10") {
        nameday = "Danuty, Remigiusza";
    } else if (DOM === "02.10") {
        nameday = "Teofila, Sławy";
    } else if (DOM === "03.10") {
        nameday = "Teresy, Heliodora";
    } else if (DOM === "04.10") {
        nameday = "Rozalii, Franciszka";
    } else if (DOM === "05.10") {
        nameday = "Igora, Flawii";
    } else if (DOM === "06.10") {
        nameday = "Artura, Brunona";
    } else if (DOM === "07.10") {
        nameday = "Marii, Marka";
    } else if (DOM === "08.10") {
        nameday = "Brygidy, Pelagii";
    } else if (DOM === "09.10") {
        nameday = "Arnolda, Dionizego";
    } else if (DOM === "10.10") {
        nameday = "Pauliny, Franciszka";
    } else if (DOM === "11.10") {
        nameday = "Emila, Aldony";
    } else if (DOM === "12.10") {
        nameday = "Eustachego, Maksymiliana";
    } else if (DOM === "13.10") {
        nameday = "Gerarda, Edwarda";
    } else if (DOM === "14.10") {
        nameday = "Alana, Kaliksta";
    } else if (DOM === "15.10") {
        nameday = "Teresy, Jadwigi";
    } else if (DOM === "16.10") {
        nameday = "Gawła, Florentyny";
    } else if (DOM === "17.10") {
        nameday = "Małgorzaty, Wiktora";
    } else if (DOM === "18.10") {
        nameday = "Juliana, Łukasza";
    } else if (DOM === "19.10") {
        nameday = "Pelagii, Piotra";
    } else if (DOM === "20.10") {
        nameday = "Ireny, Jana";
    } else if (DOM === "21.10") {
        nameday = "Urszuli, Hilarego";
    } else if (DOM === "22.10") {
        nameday = "Filipa, Korduli";
    } else if (DOM === "23.10") {
        nameday = "Marleny, Seweryna";
    } else if (DOM === "24.10") {
        nameday = "Rafała, Marcina";
    } else if (DOM === "25.10") {
        nameday = "Darii, Wilhelminy";
    } else if (DOM === "26.10") {
        nameday = "Lucjana, Ewarysta";
    } else if (DOM === "27.10") {
        nameday = "Iwony, Sabiny";
    } else if (DOM === "28.10") {
        nameday = "Szymona, Tadeusza";
    } else if (DOM === "29.10") {
        nameday = "Euzebii, Wioletty";
    } else if (DOM === "30.10") {
        nameday = "Zenobii, Przemysława";
    } else if (DOM === "31.10") {
        nameday = "Urbana, Saturnina";
    } else if (DOM === "01.11") {
        nameday = "Seweryna, Wiktoryny";
    } else if (DOM === "02.11") {
        nameday = "Bohdana, Tobiasza";
    } else if (DOM === "03.11") {
        nameday = "Sylwii, Huberta";
    } else if (DOM === "04.11") {
        nameday = "Karola, Olgierda";
    } else if (DOM === "05.11") {
        nameday = "Elżbiety, Sławomira";
    } else if (DOM === "06.11") {
        nameday = "Feliksa, Leonarda";
    } else if (DOM === "07.11") {
        nameday = "Antoniego, Żytomira";
    } else if (DOM === "08.11") {
        nameday = "Seweryna, Gotfryda";
    } else if (DOM === "09.11") {
        nameday = "Ursyna, Teodora";
    } else if (DOM === "10.11") {
        nameday = "Leny, Ludomira";
    } else if (DOM === "11.11") {
        nameday = "Marcina, Bartłomieja";
    } else if (DOM === "12.11") {
        nameday = "Renaty, Witolda";
    } else if (DOM === "13.11") {
        nameday = "Mikołaja, Stanisława";
    } else if (DOM === "14.11") {
        nameday = "Rogera, Serafina";
    } else if (DOM === "15.11") {
        nameday = "Alberta, Leopolda";
    } else if (DOM === "16.11") {
        nameday = "Gertrudy, Edmunda";
    } else if (DOM === "17.11") {
        nameday = "Grzegorza, Salomei";
    } else if (DOM === "18.11") {
        nameday = "Romana, Klaudyny";
    } else if (DOM === "19.11") {
        nameday = "Elżbiety, Seweryna";
    } else if (DOM === "20.11") {
        nameday = "Feliksa, Anatola";
    } else if (DOM === "21.11") {
        nameday = "Janusza, Konrada";
    } else if (DOM === "22.11") {
        nameday = "Marka, Cecylii";
    } else if (DOM === "23.11") {
        nameday = "Adeli, Klemensa";
    } else if (DOM === "24.11") {
        nameday = "Flory, Emmy";
    } else if (DOM === "25.11") {
        nameday = "Katarzyny, Erazma";
    } else if (DOM === "26.11") {
        nameday = "Delfiny, Sylwestra";
    } else if (DOM === "27.11") {
        nameday = "Waleriana, Wirgiliusza";
    } else if (DOM === "28.11") {
        nameday = "Lesława, Zdzisława";
    } else if (DOM === "29.11") {
        nameday = "Błażeja, Saturnina";
    } else if (DOM === "30.11") {
        nameday = "Konstantego, Maury";
    } else if (DOM === "01.12") {
        nameday = "Natalii, Eligiusza";
    } else if (DOM === "02.12") {
        nameday = "Balbiny, Pauliny";
    } else if (DOM === "03.12") {
        nameday = "Franciszka, Ksawerego";
    } else if (DOM === "04.12") {
        nameday = "Barbary, Krystiana";
    } else if (DOM === "05.12") {
        nameday = "Saby, Kryspina";
    } else if (DOM === "06.12") {
        nameday = "Emiliana, Mikołaja";
    } else if (DOM === "07.12") {
        nameday = "Marcina, Ambrożego";
    } else if (DOM === "08.12") {
        nameday = "Marii, Światożara";
    } else if (DOM === "09.12") {
        nameday = "Wiesława, Leokadii";
    } else if (DOM === "10.12") {
        nameday = "Julii, Danieli";
    } else if (DOM === "11.12") {
        nameday = "Damazego, Waldemara";
    } else if (DOM === "12.12") {
        nameday = "Adelajdy, Aleksandra";
    } else if (DOM === "13.12") {
        nameday = "Łucji, Otylii";
    } else if (DOM === "14.12") {
        nameday = "Alfreda, Izydora";
    } else if (DOM === "15.12") {
        nameday = "Celiny, Waleriana";
    } else if (DOM === "16.12") {
        nameday = "Albiny, Zdzisławy";
    } else if (DOM === "17.12") {
        nameday = "Olimpii, Łazarza";
    } else if (DOM === "18.12") {
        nameday = "Gracjana, Bogusława";
    } else if (DOM === "19.12") {
        nameday = "Gabrieli, Dariusza";
    } else if (DOM === "20.12") {
        nameday = "Bogumiły, Dominika";
    } else if (DOM === "21.12") {
        nameday = "Tomasza, Tomisława";
    } else if (DOM === "22.12") {
        nameday = "Zenona, Honoraty";
    } else if (DOM === "23.12") {
        nameday = "Wiktorii, Sławomiry";
    } else if (DOM === "24.12") {
        nameday = "Adama, Ewy";
    } else if (DOM === "25.12") {
        nameday = "Anastazji, Natana";
    } else if (DOM === "26.12") {
        nameday = "Dionizego, Szczepana";
    } else if (DOM === "27.12") {
        nameday = "Cezarego, Teodora";
    } else if (DOM === "28.12") {
        nameday = "Teofila, Godzisława";
    } else if (DOM === "29.12") {
        nameday = "Dawida, Tomasza";
    } else if (DOM === "30.12") {
        nameday = "Irmy, Eugeniusza";
    } else if (DOM === "31.12") {
        nameday = "Sylwestra, Melanii";
    }


    if(weekday === 0) {
        weekday = "Niedziela"
    } else if (weekday === 1) {
        weekday = "Poniedziałek"
    } else if (weekday === 2) {
        weekday = "Wtorek"
    } else if (weekday === 3) {
        weekday = "Środa"
    } else if (weekday === 4) {
        weekday = "Czwartek"
    } else if (weekday === 5) {
        weekday = "Piątek"
    } else if (weekday === 6) {
        weekday = "Sobota"
    }

    var scrooltext = document.getElementById("date-text")

    scrooltext.innerHTML = "Dzisiaj jest:"+weekday+", "+day+"."+month+"."+year+", "+"Imieniny:"+nameday
}

function loadMsg() {
    var url = "https://piraxu.github.io/Mzp.App/Popup_alert.json?nocache=" + Date.now();

    try {
        var xhr = new ActiveXObject("MSXML2.XMLHTTP");
        xhr.open("GET", url, false);

       
        xhr.setRequestHeader("Cache-Control", "no-cache");
        xhr.setRequestHeader("Pragma", "no-cache");

        xhr.send();

        if (xhr.status == 200) {
            var data = JSON.parse(xhr.responseText);

           
            if (data.content && data.content.trim() !== "") {
                document.getElementById("msg").innerText = data.content;
                document.getElementById("msg").style.display = "block";
            }
        }
    }
    catch (e) {
      
    }

    Msgdetect();
}

function Msgdetect() {
  var mcontent=document.getElementById("msg")
  var Wrp=document.getElementById("wrapper")
  var popup_win=document.getElementById("popup-window")
    if (mcontent.innerHTML==="") {
      Wrp.style.opacity = 1
      popup_win.style.display = "none"
    } else {
      Wrp.style.opacity = 0.2
      popup_win.style.display = "block"
    }
      
    
}

function cPopup() {
    var Wrp=document.getElementById("wrapper")
  var popup_win=document.getElementById("popup-window")
  
  popup_win.style.display= "none"
  Wrp.style.opacity=1
}
