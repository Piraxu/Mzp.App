function runTimetable(relativeJsonPath) {
    var sh = new ActiveXObject("WScript.Shell");

 
    var basePath = unescape(location.pathname)
        .replace(/\//g,"\\")
        .replace(/^\\([A-Za-z]:)/,"$1")
        .replace(/[^\\]*$/,"");


    var timetablePath = basePath + "timetable.hta";


    var jsonPath = basePath + relativeJsonPath;


    var cmd = 'mshta.exe "' + timetablePath + '?plik=' + jsonPath + '"';


    sh.Run(cmd, 1, false);
}

  function setwindow() {
         var szerokosc = 319;
         var wysokosc = 586;
         window.resizeTo(szerokosc, wysokosc);
         window.moveTo(
             (screen.availWidth - szerokosc) / 2,
             (screen.availHeight - wysokosc) / 2
         );
     }

     function enforceWindowSize() {
         var szerokosc = 319;
         var wysokosc = 586;

         if (window.outerWidth !== szerokosc || window.outerHeight !== wysokosc) {
             window.resizeTo(szerokosc, wysokosc);
             window.moveTo(
                 (screen.availWidth - szerokosc) / 2,
                 (screen.availHeight - wysokosc) / 2
             );
         }
     }

     function showtable() {
      var firsttable = document.getElementById("stop-table-one")
      if (firsttable.style.display === "none") {
        firsttable.style.display = "block"
      } else {
        firsttable.style.display = "none"
      }
     }

     function showtabletwo() {
      var firsttable = document.getElementById("stop-table-two")
      if (firsttable.style.display === "none") {
        firsttable.style.display = "block"
      } else {
        firsttable.style.display = "none"
      }
     }

          function loadsettings() {
      var apptheme = readFile("..//properties//theme.prop");
      
      if(apptheme === "dark") {
        document.getElementById("css").href = "../resources/css/D_stops.css"
      } else {
        document.getElementById("css").href = "../resources/css/L_stops.css"
      }
     }
// SIG // Begin signature block
// SIG // MIIdRQYJKoZIhvcNAQcCoIIdNjCCHTICAQExDzANBglg
// SIG // hkgBZQMEAgEFADB3BgorBgEEAYI3AgEEoGkwZzAyBgor
// SIG // BgEEAYI3AgEeMCQCAQEEEBDgyQbOONQRoqMAEEvTUJAC
// SIG // AQACAQACAQACAQACAQAwMTANBglghkgBZQMEAgEFAAQg
// SIG // g+R75sKYofFTacQfzwFIiVkyK6kuxUna5RTnEXBaQH2g
// SIG // ghcoMIID6jCCAtKgAwIBAgIQOTcM87ENqadJ2ajqhwXU
// SIG // cDANBgkqhkiG9w0BAQsFADCBjDELMAkGA1UEBhMCUEwx
// SIG // EDAOBgNVBAcMB8WBw7NkxboxIDAeBgNVBAoMF1YtZmly
// SIG // bWEgTVpQIE9TVFJPxYHEmEtBMSMwIQYJKoZIhvcNAQkB
// SIG // FhRrYWxpc3oucDg3QGdtYWlsLmNvbTEkMCIGA1UEAwwb
// SIG // UHJ6ZW15c8WCYXcgS2FsaXN6IChQaXJheHUpMB4XDTI2
// SIG // MDQwNjEwNTYzMloXDTMxMDQwNjExMDYzM1owgYwxCzAJ
// SIG // BgNVBAYTAlBMMRAwDgYDVQQHDAfFgcOzZMW6MSAwHgYD
// SIG // VQQKDBdWLWZpcm1hIE1aUCBPU1RST8WBxJhLQTEjMCEG
// SIG // CSqGSIb3DQEJARYUa2FsaXN6LnA4N0BnbWFpbC5jb20x
// SIG // JDAiBgNVBAMMG1ByemVteXPFgmF3IEthbGlzeiAoUGly
// SIG // YXh1KTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
// SIG // ggEBAPCh2z59PZZF+nVN37dC0QC4Bjq6MlFBEZqWBBbP
// SIG // QjsS3/dqHgB83PmBeAcAWTuSnOECdVqXRcjf7qIR8xjq
// SIG // Qhyl0Zdp4uxHC65leMazeTiohWHVb2BKpUQMEUQFholM
// SIG // dR7DXYdChzfvCHD9RNUo+ERWbGGuNQzoLzI7d5DmeiW0
// SIG // NhrjOosloTfTWxyLQnYPTCib+CXGdJNRkc3lC7lDQ5yJ
// SIG // y4pVTcw3vIxs8lEhzocsygjZ4uBPg0TswGD9Rut9AZWo
// SIG // JqXbnOVTsjJdAJ9i2M5ZZqPXHfySRPpiXYVlGGWOFWz3
// SIG // 7r9nkDoni0wSglzbQdZjJokgEbeM7h8eru0tC9UCAwEA
// SIG // AaNGMEQwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG
// SIG // CCsGAQUFBwMDMB0GA1UdDgQWBBSLFdfeAhpCrbWdPw28
// SIG // ozu2eBhyczANBgkqhkiG9w0BAQsFAAOCAQEA4iVfEwxg
// SIG // R5ncss+D36bSNiWvQ6aa/N3LGuuAK4O4KjWyx6aOGEzk
// SIG // w1AtGNx36/Psj7tIktbEhLO1NXf+yhIFQNGVvYlSTd5d
// SIG // 12+0arvgJ588ETxq4PwHCAN62JhiaEdz2dh8hQmQ2fMF
// SIG // uc7nLSRearsyejo2LIGxBLMz+TS9DmIxTgUurNjA8cJw
// SIG // jfEq6Zi1zhDFv5my4mZAzxv3MkeoptvRXjRLALn/zcBN
// SIG // oD3O5C4wFQHeJsNBCAK5SyMk1s+J1Qlylsci3vkgF7I3
// SIG // VLtWL8EVoVQ1Q998TAeJ9Te6QPjNncRzjjtGrc0V6Kmj
// SIG // ZWOXvDZRik5/7eBJhCO0tL3pLDCCBY0wggR1oAMCAQIC
// SIG // EA6bGI750C3n79tQ4ghAGFowDQYJKoZIhvcNAQEMBQAw
// SIG // ZTELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0
// SIG // IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEk
// SIG // MCIGA1UEAxMbRGlnaUNlcnQgQXNzdXJlZCBJRCBSb290
// SIG // IENBMB4XDTIyMDgwMTAwMDAwMFoXDTMxMTEwOTIzNTk1
// SIG // OVowYjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lD
// SIG // ZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNv
// SIG // bTEhMB8GA1UEAxMYRGlnaUNlcnQgVHJ1c3RlZCBSb290
// SIG // IEc0MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKC
// SIG // AgEAv+aQc2jeu+RdSjwwIjBpM+zCpyUuySE98orYWcLh
// SIG // Kac9WKt2ms2uexuEDcQwH/MbpDgW61bGl20dq7J58soR
// SIG // 0uRf1gU8Ug9SH8aeFaV+vp+pVxZZVXKvaJNwwrK6dZlq
// SIG // czKU0RBEEC7fgvMHhOZ0O21x4i0MG+4g1ckgHWMpLc7s
// SIG // Xk7Ik/ghYZs06wXGXuxbGrzryc/NrDRAX7F6Zu53yEio
// SIG // ZldXn1RYjgwrt0+nMNlW7sp7XeOtyU9e5TXnMcvak17c
// SIG // jo+A2raRmECQecN4x7axxLVqGDgDEI3Y1DekLgV9iPWC
// SIG // PhCRcKtVgkEy19sEcypukQF8IUzUvK4bA3VdeGbZOjFE
// SIG // mjNAvwjXWkmkwuapoGfdpCe8oU85tRFYF/ckXEaPZPfB
// SIG // aYh2mHY9WV1CdoeJl2l6SPDgohIbZpp0yt5LHucOY67m
// SIG // 1O+SkjqePdwA5EUlibaaRBkrfsCUtNJhbesz2cXfSwQA
// SIG // zH0clcOP9yGyshG3u3/y1YxwLEFgqrFjGESVGnZifvaA
// SIG // sPvoZKYz0YkH4b235kOkGLimdwHhD5QMIR2yVCkliWzl
// SIG // DlJRR3S+Jqy2QXXeeqxfjT/JvNNBERJb5RBQ6zHFynIW
// SIG // IgnffEx1P2PsIV/EIFFrb7GrhotPwtZFX50g/KEexcCP
// SIG // orF+CiaZ9eRpL5gdLfXZqbId5RsCAwEAAaOCATowggE2
// SIG // MA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFOzX44LS
// SIG // cV1kTN8uZz/nupiuHA9PMB8GA1UdIwQYMBaAFEXroq/0
// SIG // ksuCMS1Ri6enIZ3zbcgPMA4GA1UdDwEB/wQEAwIBhjB5
// SIG // BggrBgEFBQcBAQRtMGswJAYIKwYBBQUHMAGGGGh0dHA6
// SIG // Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBDBggrBgEFBQcwAoY3
// SIG // aHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lD
// SIG // ZXJ0QXNzdXJlZElEUm9vdENBLmNydDBFBgNVHR8EPjA8
// SIG // MDqgOKA2hjRodHRwOi8vY3JsMy5kaWdpY2VydC5jb20v
// SIG // RGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3JsMBEGA1Ud
// SIG // IAQKMAgwBgYEVR0gADANBgkqhkiG9w0BAQwFAAOCAQEA
// SIG // cKC/Q1xV5zhfoKN0Gz22Ftf3v1cHvZqsoYcs7IVeqRq7
// SIG // IviHGmlUIu2kiHdtvRoU9BNKei8ttzjv9P+Aufih9/Jy
// SIG // 3iS8UgPITtAq3votVs/59PesMHqai7Je1M/RQ0SbQyHr
// SIG // lnKhSLSZy51PpwYDE3cnRNTnf+hZqPC/Lwum6fI0POz3
// SIG // A8eHqNJMQBk1RmppVLC4oVaO7KTVPeix3P0c2PR3WlxU
// SIG // jG/voVA9/HYJaISfb8rbII01YBwCA8sgsKxYoA5AY8WY
// SIG // IsGyWfVVa88nq2x2zm8jLfR+cWojayL/ErhULSd+2DrZ
// SIG // 8LaHlv1b0VysGMNNn3O3AamfV6peKOK5lDCCBrQwggSc
// SIG // oAMCAQICEA3HrFcF/yGZLkBDIgw6SYYwDQYJKoZIhvcN
// SIG // AQELBQAwYjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERp
// SIG // Z2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0
// SIG // LmNvbTEhMB8GA1UEAxMYRGlnaUNlcnQgVHJ1c3RlZCBS
// SIG // b290IEc0MB4XDTI1MDUwNzAwMDAwMFoXDTM4MDExNDIz
// SIG // NTk1OVowaTELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRp
// SIG // Z2lDZXJ0LCBJbmMuMUEwPwYDVQQDEzhEaWdpQ2VydCBU
// SIG // cnVzdGVkIEc0IFRpbWVTdGFtcGluZyBSU0E0MDk2IFNI
// SIG // QTI1NiAyMDI1IENBMTCCAiIwDQYJKoZIhvcNAQEBBQAD
// SIG // ggIPADCCAgoCggIBALR4MdMKmEFyvjxGwBysddujRmh0
// SIG // tFEXnU2tjQ2UtZmWgyxU7UNqEY81FzJsQqr5G7A6c+Gh
// SIG // /qm8Xi4aPCOo2N8S9SLrC6Kbltqn7SWCWgzbNfiR+2fk
// SIG // HUiljNOqnIVD/gG3SYDEAd4dg2dDGpeZGKe+42DFUF0m
// SIG // R/vtLa4+gKPsYfwEu7EEbkC9+0F2w4QJLVSTEG8yAR2C
// SIG // QWIM1iI5PHg62IVwxKSpO0XaF9DPfNBKS7Zazch8NF5v
// SIG // p7eaZ2CVNxpqumzTCNSOxm+SAWSuIr21Qomb+zzQWKhx
// SIG // KTVVgtmUPAW35xUUFREmDrMxSNlr/NsJyUXzdtFUUt4a
// SIG // S4CEeIY8y9IaaGBpPNXKFifinT7zL2gdFpBP9qh8SdLn
// SIG // Eut/GcalNeJQ55IuwnKCgs+nrpuQNfVmUB5KlCX3ZA4x
// SIG // 5HHKS+rqBvKWxdCyQEEGcbLe1b8Aw4wJkhU1JrPsFfxW
// SIG // 1gaou30yZ46t4Y9F20HHfIY4/6vHespYMQmUiote8lad
// SIG // jS/nJ0+k6MvqzfpzPDOy5y6gqztiT96Fv/9bH7mQyogx
// SIG // G9QEPHrPV6/7umw052AkyiLA6tQbZl1KhBtTasySkuJD
// SIG // psZGKdlsjg4u70EwgWbVRSX1Wd4+zoFpp4Ra+MlKM2ba
// SIG // oD6x0VR4RjSpWM8o5a6D8bpfm4CLKczsG7ZrIGNTAgMB
// SIG // AAGjggFdMIIBWTASBgNVHRMBAf8ECDAGAQH/AgEAMB0G
// SIG // A1UdDgQWBBTvb1NK6eQGfHrK4pBW9i/USezLTjAfBgNV
// SIG // HSMEGDAWgBTs1+OC0nFdZEzfLmc/57qYrhwPTzAOBgNV
// SIG // HQ8BAf8EBAMCAYYwEwYDVR0lBAwwCgYIKwYBBQUHAwgw
// SIG // dwYIKwYBBQUHAQEEazBpMCQGCCsGAQUFBzABhhhodHRw
// SIG // Oi8vb2NzcC5kaWdpY2VydC5jb20wQQYIKwYBBQUHMAKG
// SIG // NWh0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdp
// SIG // Q2VydFRydXN0ZWRSb290RzQuY3J0MEMGA1UdHwQ8MDow
// SIG // OKA2oDSGMmh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9E
// SIG // aWdpQ2VydFRydXN0ZWRSb290RzQuY3JsMCAGA1UdIAQZ
// SIG // MBcwCAYGZ4EMAQQCMAsGCWCGSAGG/WwHATANBgkqhkiG
// SIG // 9w0BAQsFAAOCAgEAF877FoAc/gc9EXZxML2+C8i1NKZ/
// SIG // zdCHxYgaMH9Pw5tcBnPw6O6FTGNpoV2V4wzSUGvI9NAz
// SIG // aoQk97frPBtIj+ZLzdp+yXdhOP4hCFATuNT+ReOPK0mC
// SIG // efSG+tXqGpYZ3essBS3q8nL2UwM+NMvEuBd/2vmdYxDC
// SIG // vwzJv2sRUoKEfJ+nN57mQfQXwcAEGCvRR2qKtntujB71
// SIG // WPYAgwPyWLKu6RnaID/B0ba2H3LUiwDRAXx1Neq9ydOa
// SIG // l95CHfmTnM4I+ZI2rVQfjXQA1WSjjf4J2a7jLzWGNqNX
// SIG // +DF0SQzHU0pTi4dBwp9nEC8EAqoxW6q17r0z0noDjs6+
// SIG // BFo+z7bKSBwZXTRNivYuve3L2oiKNqetRHdqfMTCW/Nm
// SIG // KLJ9M+MtucVGyOxiDf06VXxyKkOirv6o02OoXN4bFzK0
// SIG // vlNMsvhlqgF2puE6FndlENSmE+9JGYxOGLS/D284NHNb
// SIG // oDGcmWXfwXRy4kbu4QFhOm0xJuF2EZAOk5eCkhSxZON3
// SIG // rGlHqhpB/8MluDezooIs8CVnrpHMiD2wL40mm53+/j7t
// SIG // FaxYKIqL0Q4ssd8xHZnIn/7GELH3IdvG2XlM9q7WP/Uw
// SIG // gOkw/HQtyRN62JK4S1C8uw3PdBunvAZapsiI5YKdvlar
// SIG // Evf8EA+8hcpSM9LHJmyrxaFtoza2zNaQ9k+5t1wwggbt
// SIG // MIIE1aADAgECAhAKgO8YS43xBYLRxHanlXRoMA0GCSqG
// SIG // SIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQK
// SIG // Ew5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNl
// SIG // cnQgVHJ1c3RlZCBHNCBUaW1lU3RhbXBpbmcgUlNBNDA5
// SIG // NiBTSEEyNTYgMjAyNSBDQTEwHhcNMjUwNjA0MDAwMDAw
// SIG // WhcNMzYwOTAzMjM1OTU5WjBjMQswCQYDVQQGEwJVUzEX
// SIG // MBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNVBAMT
// SIG // MkRpZ2lDZXJ0IFNIQTI1NiBSU0E0MDk2IFRpbWVzdGFt
// SIG // cCBSZXNwb25kZXIgMjAyNSAxMIICIjANBgkqhkiG9w0B
// SIG // AQEFAAOCAg8AMIICCgKCAgEA0EasLRLGntDqrmBWsytX
// SIG // um9R/4ZwCgHfyjfMGUIwYzKomd8U1nH7C8Dr0cVMF3Bs
// SIG // fAFI54um8+dnxk36+jx0Tb+k+87H9WPxNyFPJIDZHhAq
// SIG // lUPt281mHrBbZHqRK71Em3/hCGC5KyyneqiZ7syvFXJ9
// SIG // A72wzHpkBaMUNg7MOLxI6E9RaUueHTQKWXymOtRwJXcr
// SIG // cTTPPT2V1D/+cFllESviH8YjoPFvZSjKs3SKO1QNUdFd
// SIG // 2adw44wDcKgH+JRJE5Qg0NP3yiSyi5MxgU6cehGHr7zo
// SIG // u1znOM8odbkqoK+lJ25LCHBSai25CFyD23DZgPfDrJJJ
// SIG // K77epTwMP6eKA0kWa3osAe8fcpK40uhktzUd/Yk0xUvh
// SIG // DU6lvJukx7jphx40DQt82yepyekl4i0r8OEps/FNO4ah
// SIG // fvAk12hE5FVs9HVVWcO5J4dVmVzix4A77p3awLbr89A9
// SIG // 0/nWGjXMGn7FQhmSlIUDy9Z2hSgctaepZTd0ILIUbWuh
// SIG // KuAeNIeWrzHKYueMJtItnj2Q+aTyLLKLM0MheP/9w6Ct
// SIG // juuVHJOVoIJ/DtpJRE7Ce7vMRHoRon4CWIvuiNN1Lk9Y
// SIG // +xZ66lazs2kKFSTnnkrT3pXWETTJkhd76CIDBbTRofOs
// SIG // NyEhzZtCGmnQigpFHti58CSmvEyJcAlDVcKacJ+A9/z7
// SIG // eacCAwEAAaOCAZUwggGRMAwGA1UdEwEB/wQCMAAwHQYD
// SIG // VR0OBBYEFOQ7/PIx7f391/ORcWMZUEPPYYzoMB8GA1Ud
// SIG // IwQYMBaAFO9vU0rp5AZ8esrikFb2L9RJ7MtOMA4GA1Ud
// SIG // DwEB/wQEAwIHgDAWBgNVHSUBAf8EDDAKBggrBgEFBQcD
// SIG // CDCBlQYIKwYBBQUHAQEEgYgwgYUwJAYIKwYBBQUHMAGG
// SIG // GGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBdBggrBgEF
// SIG // BQcwAoZRaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29t
// SIG // L0RpZ2lDZXJ0VHJ1c3RlZEc0VGltZVN0YW1waW5nUlNB
// SIG // NDA5NlNIQTI1NjIwMjVDQTEuY3J0MF8GA1UdHwRYMFYw
// SIG // VKBSoFCGTmh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9E
// SIG // aWdpQ2VydFRydXN0ZWRHNFRpbWVTdGFtcGluZ1JTQTQw
// SIG // OTZTSEEyNTYyMDI1Q0ExLmNybDAgBgNVHSAEGTAXMAgG
// SIG // BmeBDAEEAjALBglghkgBhv1sBwEwDQYJKoZIhvcNAQEL
// SIG // BQADggIBAGUqrfEcJwS5rmBB7NEIRJ5jQHIh+OT2Ik/b
// SIG // NYulCrVvhREafBYF0RkP2AGr181o2YWPoSHz9iZEN/FP
// SIG // sLSTwVQWo2H62yGBvg7ouCODwrx6ULj6hYKqdT8wv2UV
// SIG // +Kbz/3ImZlJ7YXwBD9R0oU62PtgxOao872bOySCILdBg
// SIG // hQ/ZLcdC8cbUUO75ZSpbh1oipOhcUT8lD8QAGB9lctZT
// SIG // TOJM3pHfKBAEcxQFoHlt2s9sXoxFizTeHihsQyfFg5fx
// SIG // UFEp7W42fNBVN4ueLaceRf9Cq9ec1v5iQMWTFQa0xNqI
// SIG // tH3CPFTG7aEQJmmrJTV3Qhtfparz+BW60OiMEgV5GWoB
// SIG // y4RVPRwqxv7Mk0Sy4QHs7v9y69NBqycz0BZwhB9WOfOu
// SIG // /CIJnzkQTwtSSpGGhLdjnQ4eBpjtP+XB3pQCtv4E5UCS
// SIG // Dag6+iX8MmB10nfldPF9SVD7weCC3yXZi/uuhqdwkgVx
// SIG // uiMFzGVFwYbQsiGnoa9F5AaAyBjFBtXVLcKtapnMG3VH
// SIG // 3EmAp/jsJ3FVF3+d1SVDTmjFjLbNFZUWMXuZyvgLfgyP
// SIG // ehwJVxwC+UpX2MSey2ueIu9THFVkT+um1vshETaWyQo8
// SIG // gmBto/m3acaP9QsuLj3FNwFlTxq25+T4QwX9xa6ILs84
// SIG // ZPvmpovq90K8eWyG2N01c4IhSOxqt81nMYIFdTCCBXEC
// SIG // AQEwgaEwgYwxCzAJBgNVBAYTAlBMMRAwDgYDVQQHDAfF
// SIG // gcOzZMW6MSAwHgYDVQQKDBdWLWZpcm1hIE1aUCBPU1RS
// SIG // T8WBxJhLQTEjMCEGCSqGSIb3DQEJARYUa2FsaXN6LnA4
// SIG // N0BnbWFpbC5jb20xJDAiBgNVBAMMG1ByemVteXPFgmF3
// SIG // IEthbGlzeiAoUGlyYXh1KQIQOTcM87ENqadJ2ajqhwXU
// SIG // cDANBglghkgBZQMEAgEFAKB8MBAGCisGAQQBgjcCAQwx
// SIG // AjAAMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwG
// SIG // CisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
// SIG // SIb3DQEJBDEiBCDILcgZ/hr3md1hPTbETYjGkd2XJJds
// SIG // s/VyI4xqRJpCxzANBgkqhkiG9w0BAQEFAASCAQCewCQC
// SIG // LT/cSozyW0Wyo0JYbS0l/bwowvasWakb3Pvq9kQJvVly
// SIG // eol59SnP4laGYGqarHhZIuljurw74qxh0KV3UqdvLuHp
// SIG // +kqb4n4tSofoDT5OQo/+RErBuRHjCMNnJFbxFX1k+4WF
// SIG // FVF97uIC2nnCnJh0ztAVbYluYpiX4PZeoHbgh7q8Frcx
// SIG // wYK1Roazh6SGrEclzo8wmO72dkscJvUt5lfylTWuYVqT
// SIG // Pr+al0tOslwVp7GlJwblmRVTtGGmyOaFRzS39IJYYR8Q
// SIG // EVrGPWg5yitXNFPlvaOUh0dJ4vDth09C7JAslf9Uz1dV
// SIG // ykvZjEMjMj4u6IAVoDekdD7O+UEeoYIDJjCCAyIGCSqG
// SIG // SIb3DQEJBjGCAxMwggMPAgEBMH0waTELMAkGA1UEBhMC
// SIG // VVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMUEwPwYD
// SIG // VQQDEzhEaWdpQ2VydCBUcnVzdGVkIEc0IFRpbWVTdGFt
// SIG // cGluZyBSU0E0MDk2IFNIQTI1NiAyMDI1IENBMQIQCoDv
// SIG // GEuN8QWC0cR2p5V0aDANBglghkgBZQMEAgEFAKBpMBgG
// SIG // CSqGSIb3DQEJAzELBgkqhkiG9w0BBwEwHAYJKoZIhvcN
// SIG // AQkFMQ8XDTI2MDQwNjExMTE1N1owLwYJKoZIhvcNAQkE
// SIG // MSIEID7qGyjpDYj/AvFwmYDozNHyO78U84DsnuGejHDZ
// SIG // t9dgMA0GCSqGSIb3DQEBAQUABIICAJHvn+wNJK8/D5CD
// SIG // UWhLQQo/CocwDOdRdIjoDXRizslcfyDhGYWd+fBJ1gSH
// SIG // e6ZP/cLz8zZ9G+993IYSETPHE7SuaVO2sI99dJTqwJtX
// SIG // KkFozYMFUL4rQ/0m8QTwqnZgO+dNmwbq7LWz0B1m0kHb
// SIG // 7ejr7rsXIRfWxqz6Okh58EglAJdljON7VrSFekMOZXAz
// SIG // CxwBm4QJoZeGO3AjhCpub+8iYqDOdXsmjro03pNNgbRl
// SIG // KCNz4m+JDK4pF9ls3XYM2mTCCjR9ldslBh9imAHLu/BQ
// SIG // Ln3VX9H+riUsFhYoOxFEGb3fsntOnz5oyuc0887xBCtr
// SIG // 7QmA0VoPPG9PKIFnWD1lZB/OJvMo1fXjb30Ktny3L70B
// SIG // y1VUnhZ/+wI0oaFDFT78HDx1L50vx9ODV/oZ+gXDVLCd
// SIG // dEbS6+lbWFOBgnTJb5fnIYZZ5gpG2sXmuMhztW92jRS5
// SIG // LcQHihX///SVQxOoCa0xXrZH5n0vhJKU7/RiaS8f5Z9R
// SIG // pzmHaHDRrpus1kSDqIHStfdlggXiad5qUqbmQJgl87RZ
// SIG // du8Cm90tFhNcs763LVVjDFj+GE7drSAfNWmJjPMvp1rG
// SIG // xgwlQSrUBHU7PJknSIgbMpQvl8a9ZL0XPMRiyE/aeBGE
// SIG // e1t3Qodb4tRySIRabw+/PZHzKeo6PKo+b675W7JSkmGC
// SIG // rjnkLaUt
// SIG // End signature block
