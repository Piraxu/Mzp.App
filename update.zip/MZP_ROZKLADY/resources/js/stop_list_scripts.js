function runTimetable(relativeJsonPath) {
    var sh = new ActiveXObject("WScript.Shell");

 
    var basePath = unescape(location.pathname)
        .replace(/\//g,"\\")
        .replace(/^\\([A-Za-z]:)/,"$1")
        .replace(/[^\\]*$/,"");


    var timetablePath = basePath + "timetable.hta";


    var jsonPath = basePath + relativeJsonPath;


    var cmd = 'mshta.exe "' + timetablePath + '?plik=' + jsonPath + '"';


    sh.Run(cmd, 1, false);
}

  function setwindow() {
         var szerokosc = 319;
         var wysokosc = 586;
         window.resizeTo(szerokosc, wysokosc);
         window.moveTo(
             (screen.availWidth - szerokosc) / 2,
             (screen.availHeight - wysokosc) / 2
         );
     }

     function enforceWindowSize() {
         var szerokosc = 319;
         var wysokosc = 586;

         if (window.outerWidth !== szerokosc || window.outerHeight !== wysokosc) {
             window.resizeTo(szerokosc, wysokosc);
             window.moveTo(
                 (screen.availWidth - szerokosc) / 2,
                 (screen.availHeight - wysokosc) / 2
             );
         }
     }

     function showtable() {
      var firsttable = document.getElementById("stop-table-one")
      if (firsttable.style.display === "none") {
        firsttable.style.display = "block"
      } else {
        firsttable.style.display = "none"
      }
     }

     function showtabletwo() {
      var firsttable = document.getElementById("stop-table-two")
      if (firsttable.style.display === "none") {
        firsttable.style.display = "block"
      } else {
        firsttable.style.display = "none"
      }
     }

          function loadsettings() {
      var apptheme = readFile("..//properties//theme.prop");
      
      if(apptheme === "dark") {
        document.getElementById("css").href = "../resources/css/D_stops.css"
      } else {
        document.getElementById("css").href = "../resources/css/L_stops.css"
      }
     }