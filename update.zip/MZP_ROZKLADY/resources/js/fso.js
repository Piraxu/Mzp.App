function runFile(p) {
    var sh = new ActiveXObject("WScript.Shell");
    sh.Run(p);
}

   function writeFile(relativePath, content) {
    try {
        var fso = new ActiveXObject("Scripting.FileSystemObject");
        var sciezkaHTA = unescape(location.pathname);
        if (sciezkaHTA.charAt(0) === "/") sciezkaHTA = sciezkaHTA.substr(1);
        sciezkaHTA = sciezkaHTA.replace(/\//g, "\\");
        var folderHTA = fso.GetParentFolderName(sciezkaHTA);
        var sciezkaPliku = fso.BuildPath(folderHTA, relativePath);

        var plik = fso.CreateTextFile(sciezkaPliku, true);
        plik.Write(content);
        plik.Close();
    } catch (e) {
        alert("Błąd zapisu ustawień: " + e.message);
    }
}
   
   function readFile(relativePath) {
    try {
        var fso = new ActiveXObject("Scripting.FileSystemObject");
        
       
        var sciezkaHTA = unescape(location.pathname);
        if (sciezkaHTA.charAt(0) === "/") {
            sciezkaHTA = sciezkaHTA.substr(1);
        }
        sciezkaHTA = sciezkaHTA.replace(/\//g, "\\");
        var folderHTA = fso.GetParentFolderName(sciezkaHTA);
        
        
        var sciezkaPliku = fso.BuildPath(folderHTA, relativePath);
        
        if (fso.FileExists(sciezkaPliku)) {
            var plik = fso.OpenTextFile(sciezkaPliku, 1);
            var zawartosc = plik.ReadAll();
            plik.Close();
            return zawartosc.replace(/^\s+|\s+$/g, ''); 
        } else {
            return "Brak pliku";
        }
    } catch (e) {
        return "Błąd odczytu";
    }
}

function fileExists(relativePath) {
    try {
        var fso = new ActiveXObject("Scripting.FileSystemObject");
        
        // Twoja metoda wyliczania folderu bazowego HTA
        var sciezkaHTA = unescape(location.pathname);
        if (sciezkaHTA.charAt(0) === "/") sciezkaHTA = sciezkaHTA.substr(1);
        sciezkaHTA = sciezkaHTA.replace(/\//g, "\\");
        var folderHTA = fso.GetParentFolderName(sciezkaHTA);
        
        // Łączenie ścieżki bazowej z Twoją relatywną (np. ..\plik.bat)
        var sciezkaPliku = fso.BuildPath(folderHTA, relativePath);

        return fso.FileExists(sciezkaPliku);
    } catch (e) {
        // W razie błędu (np. brak uprawnień do folderu) zwraca false
        return false;
    }
}

function fileContains(relativePath, phrase) {
    try {
        var fso = new ActiveXObject("Scripting.FileSystemObject");
        var sciezkaHTA = unescape(location.pathname).replace(/^\//, "").replace(/\//g, "\\");
        var folderHTA = fso.GetParentFolderName(sciezkaHTA);
        var sciezkaPliku = fso.BuildPath(folderHTA, relativePath);

        if (fso.FileExists(sciezkaPliku)) {
            var plik = fso.OpenTextFile(sciezkaPliku, 1);
            var zawartosc = plik.ReadAll();
            plik.Close();
            
            // indexOf zwraca pozycję frazy. Jeśli nie znajdzie, zwraca -1.
            return zawartosc.indexOf(phrase) !== -1;
        }
        return false;
    } catch (e) {
        return false;
    }
}