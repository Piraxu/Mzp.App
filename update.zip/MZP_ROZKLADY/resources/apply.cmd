taskkill /f /im mshta.exe
start main.hta