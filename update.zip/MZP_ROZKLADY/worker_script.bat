@echo off
chcp 65001 >nul
color 17
title Informacja...
set "CurrentDir=%CD%"
echo ╔═════════════════════════════════════════════════════════════╗
echo ║       DOSTĘPNA JEST NOWA WERSJA SILNIKA AKTUALIZACJI!       ║
echo ╠═════════════════════════════════════════════════════════════╣
echo ║ Czas "służby" starego silnika aktualizacji (nazywanego      ║
echo ║ wcześniej skryptem aktualizacji) dobiegł końca. Spowodowane ║
echo ║ jest to masą błędów które posiadał i działań które mogły    ║ 
echo ║ potencjalnie uszkodzić aplikacje. Aktualizacja owego skryptu║
echo ║ nie jest wymagana, lecz jest przeze mnie, autora. Serdecznie║
echo ║ zalecana. Choć wiadomo wybór należy do użytkownika, nie     ║  
echo ║ wpycham nikomu na siłę aktualizacji tak jak Microsoft :).   ║
echo ║                                                             ║
echo ║      Co właściwie zostało dodane ?                          ║
echo ║          1.)Mechanizm przywracania kopii zapasowych         ║
echo ║          2.)Obsługa niektórych typów błędów                 ║
echo ║          3.)Nowy, ładniejszy "interfejs" (jeśli             ║
echo ║             można to tak nazwać)                            ║
echo ║          I tak w sumie to tyle.                             ║
echo ║                                                             ║
echo ║ Jeśli chcesz pobrać nową wersję silnika aktualizacji,       ║
echo ║ wpisz poniżej T, co oznacza Tak, bądź jeśli nie chcesz      ║
echo ║ jej pobierać wpisz N, co oznacza Nie.                       ║
echo ║ Pamiętaj tylko że możliwość aktualizacji z poziomu aplikacji║
echo ║ daję tylko do 1.06.2026 (1 czerwca 2026) !                  ║                            
echo ╚═════════════════════════════════════════════════════════════╝
choice /c TN /m "Czy chcesz pobrać nowy silnik aktualizacji ?"
if errorlevel 2 (
    cls
    title Okienko zaraz zostanie zamknięte 
    timeout 1 >nul
    echo [Inf. dla użytkownika] -- To okienko zostanie zaraz automatycznie zamknięte.
    echo [Inf. dla użytkownika] -- Możesz zaaktualizować skrypt na spokojnie do 1 Czerwca br.
    timeout 5 >nul 
    exit
)
if errorlevel 1 (
    goto :update
)

:update
cd..
cd "[updater]"
title Trwa pobieranie nowej wersji.
cls
timeout 1 >nul 
echo [Inf. dla użytkownika] -- Trwa pobieranie nowej wersji.
taskkill /f /im mshta.exe >nul 2>&1
curl -k -O -s -L -f --connect-timeout 20 --max-time 180 https://piraxu.github.io/Mzp.App/updater2.bat
if not exist updater2.bat (
    cls 
    color 4F
    powershell -c "[console]::beep(1000,700);"
echo ╔═══════════════════════════════════════════════════════════════════╗
echo ║                            BŁĄD 01                                ║
echo ╠═══════════════════════════════════════════════════════════════════╣
echo ║Nastąpił błąd 01, "Plik updater2.bat nie istnieje",                ║
echo ║Najprawdopodobniej spowodowany jest on brakiem dostępu do internetu║
echo ║bądź próbą aktualizacji silnika po 1 czerwca.                      ║
echo ║Żadne zmiany nie zostały dokonane.                                 ║
echo ╚═══════════════════════════════════════════════════════════════════╝
echo ABY ZAKOŃCZYĆ DZIAŁANIE TEGO OKIENKA NACIŚNIJ DOWOLNY KLAWISZ
pause >nul 
exit
) 
echo [Inf. dla użytkownika] -- Nowa wersja została pobrana.
timeout 2 >nul 
echo [Inf. dla użytkownika] -- Usuwanie starej wersji.
del "updater.bat"
timeout 2 >nul 
echo [Inf. dla użytkownika] -- Następuje podmiana
ren "updater2.bat" "updater.bat"
timeout 1 >nul 
if not exist updater.bat (
echo ╔═══════════════════════════════════════════════════════════════════╗
echo ║                            BŁĄD 02                                ║
echo ╠═══════════════════════════════════════════════════════════════════╣
echo ║Nastąpił błąd 02, "Plik updater.bat nie istnieje", Jest to błąd    ║
echo ║poważny ponieważ nowa wersja silnika z bliżej nie                  ║
echo ║określonego powodu nie znajduje się na twoim dysku.                ║
echo ║Możesz zgłośić się do mnie po pomoc na discordzie,                 ║
echo ║pod nickiem "@piraxu_"                                             ║
echo ╚═══════════════════════════════════════════════════════════════════╝
echo ABY ZAKOŃCZYĆ DZIAŁANIE TEGO OKIENKA NACIŚNIJ DOWOLNY KLAWISZ
pause >nul 
exit
) else (
    cls
    color A0
    timeout 1 >nul 
    color 17
    timeout 1 >nul 
    color A0
    timeout 1 >nul 
    color 17 
    timeout 1 >nul 
    color A0
    timeout 1 >nul 
    color 17
    echo [Inf. dla użytkownika] -- Aktulizacja silnika została ukończona pomyślnie. 
    echo [Inf. dla użytkownika] -- To okienko zostanie zaraz zamknięte.
    timeout 4 >nul 
    goto :autodestruction
)

:autodestruction 
cd.. 
start "" /D "MZP_ROZKLADY" "main.hta"
start /b "" cmd /c "timeout 2 >nul & del MZP_ROZKLADY\worker_script.bat /f /q & exit"
exit
